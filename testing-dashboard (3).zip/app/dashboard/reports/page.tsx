import type { Metadata } from "next"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { ReportsList } from "@/components/reports/reports-list"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export const metadata: Metadata = {
  title: "Reports - WebInsight AI",
  description: "View your website analysis reports",
}

export default function ReportsPage() {
  return (
    <div className="flex flex-col gap-6">
      <DashboardHeader heading="Reports" subheading="View your website analysis reports and insights" />

      <Card>
        <CardHeader>
          <CardTitle>Analysis Reports</CardTitle>
          <CardDescription>View detailed reports of your website analysis</CardDescription>
        </CardHeader>
        <CardContent>
          <ReportsList />
        </CardContent>
      </Card>
    </div>
  )
}

