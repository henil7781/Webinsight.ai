import type { Metadata } from "next"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ActivityFeed } from "@/components/activity/activity-feed"
import { ActivityCalendar } from "@/components/activity/activity-calendar"
import { ActivityFilters } from "@/components/activity/activity-filters"
import { Button } from "@/components/ui/button"
import { Download } from "lucide-react"

export const metadata: Metadata = {
  title: "Activity - WebInsight AI",
  description: "Track all activity and changes across your websites",
}

export default function ActivityPage() {
  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <DashboardHeader heading="Activity" subheading="Track all activity and changes across your websites" />
        <Button variant="outline" size="sm">
          <Download className="mr-2 h-4 w-4" />
          Export Activity Log
        </Button>
      </div>

      <Card>
        <CardHeader className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2">
          <div>
            <CardTitle>Activity Log</CardTitle>
            <CardDescription>Recent actions and changes to your websites</CardDescription>
          </div>
          <ActivityFilters />
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="feed" className="space-y-4">
            <TabsList>
              <TabsTrigger value="feed">Activity Feed</TabsTrigger>
              <TabsTrigger value="calendar">Calendar View</TabsTrigger>
            </TabsList>
            <TabsContent value="feed">
              <ActivityFeed />
            </TabsContent>
            <TabsContent value="calendar">
              <ActivityCalendar />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}

