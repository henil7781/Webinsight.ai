import type { Metadata } from "next"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { WebsiteAnalyzer } from "@/components/analyze/website-analyzer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export const metadata: Metadata = {
  title: "Analyze Website - WebInsight AI",
  description: "Analyze a website for SEO, performance, and security",
}

export default function AnalyzePage() {
  return (
    <div className="flex flex-col gap-6">
      <DashboardHeader
        heading="Analyze Website"
        subheading="Enter a URL to analyze a website for SEO, performance, and security"
      />

      <Card>
        <CardHeader>
          <CardTitle>Website Analysis</CardTitle>
          <CardDescription>
            Our AI will analyze the website and provide insights on SEO, performance, and security
          </CardDescription>
        </CardHeader>
        <CardContent>
          <WebsiteAnalyzer />
        </CardContent>
      </Card>
    </div>
  )
}

