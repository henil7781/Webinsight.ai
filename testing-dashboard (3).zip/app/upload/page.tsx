import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { FileUploader } from "@/components/file-uploader"
import { RecentUploads } from "@/components/recent-uploads"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { InfoIcon } from "lucide-react"

export default function UploadPage() {
  return (
    <div className="flex-1 p-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Upload Files</h1>
          <p className="text-muted-foreground">Upload your designs, requirements, or test scripts for analysis</p>
        </div>
      </div>

      <div className="grid gap-6">
        <Alert>
          <InfoIcon className="h-4 w-4" />
          <AlertTitle>Authentication Required</AlertTitle>
          <AlertDescription>
            You need to be logged in to upload files. Please{" "}
            <Button variant="link" className="p-0 h-auto font-semibold">
              sign in
            </Button>{" "}
            or{" "}
            <Button variant="link" className="p-0 h-auto font-semibold">
              create an account
            </Button>{" "}
            to continue.
          </AlertDescription>
        </Alert>

        <Card>
          <CardHeader>
            <CardTitle>Upload Files for Analysis</CardTitle>
            <CardDescription>
              Drag and drop your Figma designs, application requirements, or test scripts
            </CardDescription>
          </CardHeader>
          <CardContent>
            <FileUploader compact={false} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recently Uploaded Files</CardTitle>
            <CardDescription>Your most recent uploads and their analysis status</CardDescription>
          </CardHeader>
          <CardContent>
            <RecentUploads />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

