import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { GitHubLogoIcon, FigmaLogoIcon } from "@radix-ui/react-icons"
import { JiraIcon, SlackIcon, CircleCiIcon, GitlabLogoIcon } from "@/components/icons"

export default function IntegrationsPage() {
  return (
    <div className="flex-1 p-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Integrations</h1>
          <p className="text-muted-foreground">Connect your testing agent with other tools and services</p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {/* GitHub Integration */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <GitHubLogoIcon className="h-6 w-6" />
                <CardTitle>GitHub</CardTitle>
              </div>
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                Connected
              </Badge>
            </div>
            <CardDescription>Sync test cases with GitHub issues and pull requests</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="github-pr-checks">PR Checks</Label>
                <Switch id="github-pr-checks" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="github-issues">Issue Tracking</Label>
                <Switch id="github-issues" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="github-actions">GitHub Actions</Label>
                <Switch id="github-actions" defaultChecked />
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full">
              Configure
            </Button>
          </CardFooter>
        </Card>

        {/* Figma Integration */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FigmaLogoIcon className="h-6 w-6" />
                <CardTitle>Figma</CardTitle>
              </div>
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                Connected
              </Badge>
            </div>
            <CardDescription>Import designs directly from Figma for testing</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="figma-auto-import">Auto Import</Label>
                <Switch id="figma-auto-import" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="figma-comments">Sync Comments</Label>
                <Switch id="figma-comments" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="figma-notifications">Notifications</Label>
                <Switch id="figma-notifications" />
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full">
              Configure
            </Button>
          </CardFooter>
        </Card>

        {/* Jira Integration */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <JiraIcon className="h-6 w-6" />
                <CardTitle>Jira</CardTitle>
              </div>
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                Connected
              </Badge>
            </div>
            <CardDescription>Sync test cases with Jira issues and projects</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="jira-issues">Issue Sync</Label>
                <Switch id="jira-issues" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="jira-projects">Project Sync</Label>
                <Switch id="jira-projects" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="jira-status">Status Updates</Label>
                <Switch id="jira-status" defaultChecked />
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full">
              Configure
            </Button>
          </CardFooter>
        </Card>

        {/* Slack Integration */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <SlackIcon className="h-6 w-6" />
                <CardTitle>Slack</CardTitle>
              </div>
              <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                Setup Required
              </Badge>
            </div>
            <CardDescription>Get notifications and reports in your Slack channels</CardDescription>
          </CardHeader>
          <CardContent className="text-center py-6">
            <p className="text-muted-foreground mb-4">
              Connect your Slack workspace to receive test reports and alerts
            </p>
          </CardContent>
          <CardFooter>
            <Button className="w-full">Connect Slack</Button>
          </CardFooter>
        </Card>

        {/* GitLab Integration */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <GitlabLogoIcon className="h-6 w-6" />
                <CardTitle>GitLab</CardTitle>
              </div>
              <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                Setup Required
              </Badge>
            </div>
            <CardDescription>Integrate with GitLab repositories and CI/CD pipelines</CardDescription>
          </CardHeader>
          <CardContent className="text-center py-6">
            <p className="text-muted-foreground mb-4">Connect your GitLab account to sync repositories and pipelines</p>
          </CardContent>
          <CardFooter>
            <Button className="w-full">Connect GitLab</Button>
          </CardFooter>
        </Card>

        {/* CI/CD Integration */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CircleCiIcon className="h-6 w-6" />
                <CardTitle>CircleCI</CardTitle>
              </div>
              <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                Setup Required
              </Badge>
            </div>
            <CardDescription>Run tests automatically in your CI/CD pipeline</CardDescription>
          </CardHeader>
          <CardContent className="text-center py-6">
            <p className="text-muted-foreground mb-4">
              Connect your CircleCI account to automate testing in your pipelines
            </p>
          </CardContent>
          <CardFooter>
            <Button className="w-full">Connect CircleCI</Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

