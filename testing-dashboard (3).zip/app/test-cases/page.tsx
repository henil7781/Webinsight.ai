import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { TestCaseTable } from "@/components/test-case-table"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TestCaseFilters } from "@/components/test-case-filters"
import { TestCaseStats } from "@/components/test-case-stats"

export default function TestCasesPage() {
  return (
    <div className="flex-1 p-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Test Cases</h1>
          <p className="text-muted-foreground">View and manage all auto-generated test cases</p>
        </div>
        <Button>Generate New Tests</Button>
      </div>

      <div className="grid gap-6">
        <TestCaseStats />

        <Card>
          <CardHeader>
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <CardTitle>Test Cases</CardTitle>
                <CardDescription>All test cases generated from your uploaded files</CardDescription>
              </div>
              <TestCaseFilters />
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all">
              <TabsList className="mb-4">
                <TabsTrigger value="all">All Tests</TabsTrigger>
                <TabsTrigger value="ui">UI Tests</TabsTrigger>
                <TabsTrigger value="functional">Functional Tests</TabsTrigger>
                <TabsTrigger value="integration">Integration Tests</TabsTrigger>
                <TabsTrigger value="e2e">E2E Tests</TabsTrigger>
              </TabsList>
              <TabsContent value="all">
                <TestCaseTable expanded={true} />
              </TabsContent>
              <TabsContent value="ui">
                <TestCaseTable expanded={true} filterType="UI" />
              </TabsContent>
              <TabsContent value="functional">
                <TestCaseTable expanded={true} filterType="Functional" />
              </TabsContent>
              <TabsContent value="integration">
                <TestCaseTable expanded={true} filterType="Integration" />
              </TabsContent>
              <TabsContent value="e2e">
                <TestCaseTable expanded={true} filterType="E2E" />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

