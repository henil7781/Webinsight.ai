import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CoverageChart } from "@/components/coverage-chart"
import { CoverageBreakdown } from "@/components/coverage-breakdown"
import { MissingElements } from "@/components/missing-elements"

export default function CoveragePage() {
  return (
    <div className="flex-1 p-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Coverage Analysis</h1>
          <p className="text-muted-foreground">Detailed breakdown of test coverage and identified gaps</p>
        </div>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Coverage Overview</CardTitle>
            <CardDescription>Visual representation of your test coverage across different categories</CardDescription>
          </CardHeader>
          <CardContent className="h-[400px]">
            <CoverageChart expanded={true} />
          </CardContent>
        </Card>

        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Coverage Breakdown</CardTitle>
              <CardDescription>Detailed analysis of coverage by component and feature</CardDescription>
            </CardHeader>
            <CardContent>
              <CoverageBreakdown />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Missing UI Elements</CardTitle>
              <CardDescription>UI components that are missing or need attention</CardDescription>
            </CardHeader>
            <CardContent>
              <MissingElements />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

