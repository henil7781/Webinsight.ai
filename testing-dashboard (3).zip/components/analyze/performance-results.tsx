"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Check, X, AlertTriangle, Info } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

interface PerformanceFactor {
  name: string
  status: "good" | "warning" | "error" | "info"
  description: string
  value?: string
  recommendation?: string
}

const mockPerformanceFactors: PerformanceFactor[] = [
  {
    name: "First Contentful Paint",
    status: "good",
    description: "Time to first contentful paint is fast.",
    value: "1.2s",
  },
  {
    name: "Largest Contentful Paint",
    status: "warning",
    description: "Largest contentful paint is slower than recommended.",
    value: "2.8s",
    recommendation: "Optimize your largest page elements and improve server response time.",
  },
  {
    name: "Cumulative Layout Shift",
    status: "good",
    description: "Your page has minimal layout shifts during loading.",
    value: "0.02",
  },
  {
    name: "Total Blocking Time",
    status: "error",
    description: "Your page has high total blocking time.",
    value: "450ms",
    recommendation: "Reduce JavaScript execution time and break up long tasks.",
  },
  {
    name: "Time to Interactive",
    status: "warning",
    description: "Time to interactive is longer than optimal.",
    value: "3.5s",
    recommendation: "Minimize main thread work and reduce JavaScript payload size.",
  },
  {
    name: "Server Response Time",
    status: "good",
    description: "Your server responds quickly to requests.",
    value: "180ms",
  },
  {
    name: "Resource Size",
    status: "warning",
    description: "Total page size is larger than recommended.",
    value: "2.8MB",
    recommendation: "Compress images, minify CSS and JavaScript, and implement lazy loading.",
  },
  {
    name: "HTTP Requests",
    status: "info",
    description: "Your page makes a moderate number of HTTP requests.",
    value: "42 requests",
    recommendation: "Consider bundling files and using HTTP/2 to improve performance.",
  },
]

export function PerformanceResults() {
  const getStatusIcon = (status: PerformanceFactor["status"]) => {
    switch (status) {
      case "good":
        return <Check className="h-5 w-5 text-green-500" />
      case "warning":
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />
      case "error":
        return <X className="h-5 w-5 text-red-500" />
      case "info":
        return <Info className="h-5 w-5 text-blue-500" />
    }
  }

  const getStatusBadge = (status: PerformanceFactor["status"]) => {
    switch (status) {
      case "good":
        return <Badge className="bg-green-500">Good</Badge>
      case "warning":
        return (
          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
            Needs Improvement
          </Badge>
        )
      case "error":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            Critical
          </Badge>
        )
      case "info":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Info
          </Badge>
        )
    }
  }

  // Calculate performance health percentages
  const totalFactors = mockPerformanceFactors.length
  const goodFactors = mockPerformanceFactors.filter((f) => f.status === "good").length
  const warningFactors = mockPerformanceFactors.filter((f) => f.status === "warning").length
  const errorFactors = mockPerformanceFactors.filter((f) => f.status === "error").length
  const infoFactors = mockPerformanceFactors.filter((f) => f.status === "info").length

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Performance Overview</CardTitle>
          <CardDescription>Summary of performance metrics for your website</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Good</span>
                <span className="text-sm text-muted-foreground">
                  {goodFactors}/{totalFactors}
                </span>
              </div>
              <Progress
                value={(goodFactors / totalFactors) * 100}
                className="h-2 bg-muted"
                indicatorClassName="bg-green-500"
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Needs Improvement</span>
                <span className="text-sm text-muted-foreground">
                  {warningFactors}/{totalFactors}
                </span>
              </div>
              <Progress
                value={(warningFactors / totalFactors) * 100}
                className="h-2 bg-muted"
                indicatorClassName="bg-yellow-500"
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Critical</span>
                <span className="text-sm text-muted-foreground">
                  {errorFactors}/{totalFactors}
                </span>
              </div>
              <Progress
                value={(errorFactors / totalFactors) * 100}
                className="h-2 bg-muted"
                indicatorClassName="bg-red-500"
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Info</span>
                <span className="text-sm text-muted-foreground">
                  {infoFactors}/{totalFactors}
                </span>
              </div>
              <Progress
                value={(infoFactors / totalFactors) * 100}
                className="h-2 bg-muted"
                indicatorClassName="bg-blue-500"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Performance Metrics</CardTitle>
          <CardDescription>Detailed analysis of performance metrics for your website</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockPerformanceFactors.map((factor, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <div className="mt-0.5">{getStatusIcon(factor.status)}</div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">{factor.name}</h3>
                        {factor.value && <Badge variant="outline">{factor.value}</Badge>}
                      </div>
                      {getStatusBadge(factor.status)}
                    </div>
                    <p className="mt-1 text-sm text-muted-foreground">{factor.description}</p>
                    {factor.recommendation && (
                      <div className="mt-2 text-sm bg-muted p-2 rounded-md">
                        <span className="font-medium">Recommendation:</span> {factor.recommendation}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

