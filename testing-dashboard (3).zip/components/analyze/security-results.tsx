"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Check, X, AlertTriangle, Info } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

interface SecurityFactor {
  name: string
  status: "good" | "warning" | "error" | "info"
  description: string
  recommendation?: string
}

const mockSecurityFactors: SecurityFactor[] = [
  {
    name: "HTTPS Implementation",
    status: "good",
    description: "Your website uses HTTPS with a valid SSL certificate.",
  },
  {
    name: "Content Security Policy",
    status: "error",
    description: "No Content Security Policy (CSP) header found.",
    recommendation: "Implement a Content Security Policy to prevent XSS attacks.",
  },
  {
    name: "X-XSS-Protection",
    status: "warning",
    description: "X-XSS-Protection header is missing.",
    recommendation: "Add the X-XSS-Protection header to help prevent cross-site scripting attacks.",
  },
  {
    name: "X-Frame-Options",
    status: "good",
    description: "X-Frame-Options header is properly set to prevent clickjacking.",
  },
  {
    name: "HSTS",
    status: "good",
    description: "HTTP Strict Transport Security (HSTS) is properly implemented.",
  },
  {
    name: "Secure Cookies",
    status: "warning",
    description: "Some cookies are missing the 'secure' flag.",
    recommendation: "Set the 'secure' flag on all cookies to ensure they're only sent over HTTPS.",
  },
  {
    name: "Mixed Content",
    status: "good",
    description: "No mixed content issues detected on your website.",
  },
  {
    name: "Outdated Libraries",
    status: "error",
    description: "Your website uses outdated JavaScript libraries with known vulnerabilities.",
    recommendation: "Update jQuery (1.11.3) and Bootstrap (3.3.5) to the latest versions.",
  },
  {
    name: "Server Information Disclosure",
    status: "warning",
    description: "Server is revealing version information in headers.",
    recommendation: "Configure your server to hide version information in HTTP headers.",
  },
]

export function SecurityResults() {
  const getStatusIcon = (status: SecurityFactor["status"]) => {
    switch (status) {
      case "good":
        return <Check className="h-5 w-5 text-green-500" />
      case "warning":
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />
      case "error":
        return <X className="h-5 w-5 text-red-500" />
      case "info":
        return <Info className="h-5 w-5 text-blue-500" />
    }
  }

  const getStatusBadge = (status: SecurityFactor["status"]) => {
    switch (status) {
      case "good":
        return <Badge className="bg-green-500">Secure</Badge>
      case "warning":
        return (
          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
            Moderate Risk
          </Badge>
        )
      case "error":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            High Risk
          </Badge>
        )
      case "info":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Info
          </Badge>
        )
    }
  }

  // Calculate security health percentages
  const totalFactors = mockSecurityFactors.length
  const goodFactors = mockSecurityFactors.filter((f) => f.status === "good").length
  const warningFactors = mockSecurityFactors.filter((f) => f.status === "warning").length
  const errorFactors = mockSecurityFactors.filter((f) => f.status === "error").length
  const infoFactors = mockSecurityFactors.filter((f) => f.status === "info").length

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Security Overview</CardTitle>
          <CardDescription>Summary of security factors analyzed on your website</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Secure</span>
                <span className="text-sm text-muted-foreground">
                  {goodFactors}/{totalFactors}
                </span>
              </div>
              <Progress
                value={(goodFactors / totalFactors) * 100}
                className="h-2 bg-muted"
                indicatorClassName="bg-green-500"
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Moderate Risk</span>
                <span className="text-sm text-muted-foreground">
                  {warningFactors}/{totalFactors}
                </span>
              </div>
              <Progress
                value={(warningFactors / totalFactors) * 100}
                className="h-2 bg-muted"
                indicatorClassName="bg-yellow-500"
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">High Risk</span>
                <span className="text-sm text-muted-foreground">
                  {errorFactors}/{totalFactors}
                </span>
              </div>
              <Progress
                value={(errorFactors / totalFactors) * 100}
                className="h-2 bg-muted"
                indicatorClassName="bg-red-500"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Security Factors</CardTitle>
          <CardDescription>Detailed analysis of security factors on your website</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockSecurityFactors.map((factor, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <div className="mt-0.5">{getStatusIcon(factor.status)}</div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h3 className="font-medium">{factor.name}</h3>
                      {getStatusBadge(factor.status)}
                    </div>
                    <p className="mt-1 text-sm text-muted-foreground">{factor.description}</p>
                    {factor.recommendation && (
                      <div className="mt-2 text-sm bg-muted p-2 rounded-md">
                        <span className="font-medium">Recommendation:</span> {factor.recommendation}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

