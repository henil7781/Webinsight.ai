"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Download, Share2 } from "lucide-react"
import { SeoResults } from "@/components/analyze/seo-results"
import { PerformanceResults } from "@/components/analyze/performance-results"
import { SecurityResults } from "@/components/analyze/security-results"

interface AnalysisResultsProps {
  url: string
}

export function AnalysisResults({ url }: AnalysisResultsProps) {
  // Mock data - in a real app, this would come from the API
  const results = {
    seoScore: 78,
    performanceScore: 85,
    securityScore: 92,
    timestamp: new Date().toISOString(),
  }

  const getScoreBadge = (score: number) => {
    if (score >= 80) {
      return <Badge className="bg-green-500">Good</Badge>
    } else if (score >= 60) {
      return (
        <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
          Needs Improvement
        </Badge>
      )
    } else {
      return (
        <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
          Poor
        </Badge>
      )
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <CardTitle>Analysis Results for {url}</CardTitle>
              <CardDescription>
                Analysis completed on {new Date().toLocaleDateString()} at {new Date().toLocaleTimeString()}
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                Export PDF
              </Button>
              <Button variant="outline" size="sm">
                <Share2 className="mr-2 h-4 w-4" />
                Share
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">SEO Score</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center">
                  <div className="relative flex h-32 w-32 items-center justify-center rounded-full">
                    <svg className="h-32 w-32">
                      <circle
                        className="text-muted stroke-current"
                        strokeWidth="12"
                        cx="64"
                        cy="64"
                        r="56"
                        fill="none"
                      />
                      <circle
                        className="text-primary stroke-current"
                        strokeWidth="12"
                        strokeLinecap="round"
                        cx="64"
                        cy="64"
                        r="56"
                        fill="none"
                        strokeDasharray="350"
                        strokeDashoffset={350 - (350 * results.seoScore) / 100}
                      />
                    </svg>
                    <span className="absolute text-2xl font-bold">{results.seoScore}</span>
                  </div>
                  <div className="mt-4 flex items-center gap-2">{getScoreBadge(results.seoScore)}</div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Performance Score</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center">
                  <div className="relative flex h-32 w-32 items-center justify-center rounded-full">
                    <svg className="h-32 w-32">
                      <circle
                        className="text-muted stroke-current"
                        strokeWidth="12"
                        cx="64"
                        cy="64"
                        r="56"
                        fill="none"
                      />
                      <circle
                        className="text-primary stroke-current"
                        strokeWidth="12"
                        strokeLinecap="round"
                        cx="64"
                        cy="64"
                        r="56"
                        fill="none"
                        strokeDasharray="350"
                        strokeDashoffset={350 - (350 * results.performanceScore) / 100}
                      />
                    </svg>
                    <span className="absolute text-2xl font-bold">{results.performanceScore}</span>
                  </div>
                  <div className="mt-4 flex items-center gap-2">{getScoreBadge(results.performanceScore)}</div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Security Score</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center">
                  <div className="relative flex h-32 w-32 items-center justify-center rounded-full">
                    <svg className="h-32 w-32">
                      <circle
                        className="text-muted stroke-current"
                        strokeWidth="12"
                        cx="64"
                        cy="64"
                        r="56"
                        fill="none"
                      />
                      <circle
                        className="text-primary stroke-current"
                        strokeWidth="12"
                        strokeLinecap="round"
                        cx="64"
                        cy="64"
                        r="56"
                        fill="none"
                        strokeDasharray="350"
                        strokeDashoffset={350 - (350 * results.securityScore) / 100}
                      />
                    </svg>
                    <span className="absolute text-2xl font-bold">{results.securityScore}</span>
                  </div>
                  <div className="mt-4 flex items-center gap-2">{getScoreBadge(results.securityScore)}</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="seo" className="space-y-4">
        <TabsList>
          <TabsTrigger value="seo">SEO Analysis</TabsTrigger>
          <TabsTrigger value="performance">Performance Analysis</TabsTrigger>
          <TabsTrigger value="security">Security Analysis</TabsTrigger>
        </TabsList>
        <TabsContent value="seo">
          <SeoResults />
        </TabsContent>
        <TabsContent value="performance">
          <PerformanceResults />
        </TabsContent>
        <TabsContent value="security">
          <SecurityResults />
        </TabsContent>
      </Tabs>
    </div>
  )
}

