"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Check, X, AlertTriangle, Info } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

interface SeoFactor {
  name: string
  status: "good" | "warning" | "error" | "info"
  description: string
  recommendation?: string
}

const mockSeoFactors: SeoFactor[] = [
  {
    name: "Title Tag",
    status: "good",
    description: "Your title tag is well-optimized and has an appropriate length.",
  },
  {
    name: "Meta Description",
    status: "warning",
    description: "Your meta description is too short (45 characters).",
    recommendation: "Aim for 150-160 characters to improve click-through rates.",
  },
  {
    name: "Heading Structure",
    status: "good",
    description: "Your page has a proper heading structure with H1, H2, and H3 tags used appropriately.",
  },
  {
    name: "Image Alt Text",
    status: "error",
    description: "5 images on your page are missing alt text.",
    recommendation: "Add descriptive alt text to all images for better accessibility and SEO.",
  },
  {
    name: "Mobile Friendliness",
    status: "good",
    description: "Your website is mobile-friendly and responsive across different screen sizes.",
  },
  {
    name: "URL Structure",
    status: "warning",
    description: "Some URLs contain parameters and are not SEO-friendly.",
    recommendation: "Use clean, descriptive URLs with keywords and avoid parameters when possible.",
  },
  {
    name: "Page Speed",
    status: "warning",
    description: "Your page load speed is average (3.2 seconds).",
    recommendation: "Aim for under 2 seconds by optimizing images and reducing JavaScript.",
  },
  {
    name: "Internal Linking",
    status: "info",
    description: "Your internal linking structure could be improved.",
    recommendation: "Add more contextual internal links to help users and search engines navigate your site.",
  },
]

export function SeoResults() {
  const getStatusIcon = (status: SeoFactor["status"]) => {
    switch (status) {
      case "good":
        return <Check className="h-5 w-5 text-green-500" />
      case "warning":
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />
      case "error":
        return <X className="h-5 w-5 text-red-500" />
      case "info":
        return <Info className="h-5 w-5 text-blue-500" />
    }
  }

  const getStatusBadge = (status: SeoFactor["status"]) => {
    switch (status) {
      case "good":
        return <Badge className="bg-green-500">Good</Badge>
      case "warning":
        return (
          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
            Needs Improvement
          </Badge>
        )
      case "error":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            Critical
          </Badge>
        )
      case "info":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Info
          </Badge>
        )
    }
  }

  // Calculate SEO health percentages
  const totalFactors = mockSeoFactors.length
  const goodFactors = mockSeoFactors.filter((f) => f.status === "good").length
  const warningFactors = mockSeoFactors.filter((f) => f.status === "warning").length
  const errorFactors = mockSeoFactors.filter((f) => f.status === "error").length
  const infoFactors = mockSeoFactors.filter((f) => f.status === "info").length

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>SEO Health Overview</CardTitle>
          <CardDescription>Summary of SEO factors analyzed on your website</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Good</span>
                <span className="text-sm text-muted-foreground">
                  {goodFactors}/{totalFactors}
                </span>
              </div>
              <Progress
                value={(goodFactors / totalFactors) * 100}
                className="h-2 bg-muted"
                indicatorClassName="bg-green-500"
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Needs Improvement</span>
                <span className="text-sm text-muted-foreground">
                  {warningFactors}/{totalFactors}
                </span>
              </div>
              <Progress
                value={(warningFactors / totalFactors) * 100}
                className="h-2 bg-muted"
                indicatorClassName="bg-yellow-500"
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Critical</span>
                <span className="text-sm text-muted-foreground">
                  {errorFactors}/{totalFactors}
                </span>
              </div>
              <Progress
                value={(errorFactors / totalFactors) * 100}
                className="h-2 bg-muted"
                indicatorClassName="bg-red-500"
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Info</span>
                <span className="text-sm text-muted-foreground">
                  {infoFactors}/{totalFactors}
                </span>
              </div>
              <Progress
                value={(infoFactors / totalFactors) * 100}
                className="h-2 bg-muted"
                indicatorClassName="bg-blue-500"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>SEO Factors</CardTitle>
          <CardDescription>Detailed analysis of SEO factors on your website</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockSeoFactors.map((factor, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <div className="mt-0.5">{getStatusIcon(factor.status)}</div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h3 className="font-medium">{factor.name}</h3>
                      {getStatusBadge(factor.status)}
                    </div>
                    <p className="mt-1 text-sm text-muted-foreground">{factor.description}</p>
                    {factor.recommendation && (
                      <div className="mt-2 text-sm bg-muted p-2 rounded-md">
                        <span className="font-medium">Recommendation:</span> {factor.recommendation}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

