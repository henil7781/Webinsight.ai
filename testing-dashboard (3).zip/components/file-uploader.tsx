"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { FileIcon, UploadCloud } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { InfoIcon } from "lucide-react"

interface FileUploaderProps {
  compact?: boolean
}

export function FileUploader({ compact = false }: FileUploaderProps) {
  const [isDragging, setIsDragging] = useState(false)
  const [files, setFiles] = useState<File[]>([])
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [isUploading, setIsUploading] = useState(false)
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = () => {
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)

    if (!isAuthenticated) {
      return
    }

    if (e.dataTransfer.files) {
      const newFiles = Array.from(e.dataTransfer.files)
      setFiles([...files, ...newFiles])
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!isAuthenticated) {
      return
    }

    if (e.target.files) {
      const newFiles = Array.from(e.target.files)
      setFiles([...files, ...newFiles])
    }
  }

  const removeFile = (index: number) => {
    const newFiles = [...files]
    newFiles.splice(index, 1)
    setFiles(newFiles)
  }

  const startAnalysis = () => {
    setIsUploading(true)

    // Simulate upload progress
    let progress = 0
    const interval = setInterval(() => {
      progress += 5
      setUploadProgress(progress)

      if (progress >= 100) {
        clearInterval(interval)
        setIsUploading(false)
        setIsAnalyzing(true)

        // Simulate analysis process
        setTimeout(() => {
          setIsAnalyzing(false)
          setFiles([])
          setUploadProgress(0)
        }, 3000)
      }
    }, 200)
  }

  const getFileTypeLabel = (fileName: string) => {
    if (fileName.endsWith(".fig") || fileName.includes("figma")) return "Figma"
    if (fileName.endsWith(".js") || fileName.endsWith(".ts") || fileName.endsWith(".jsx") || fileName.endsWith(".tsx"))
      return "Code"
    if (fileName.endsWith(".spec.js") || fileName.endsWith(".test.js")) return "Test"
    if (fileName.endsWith(".md") || fileName.endsWith(".txt") || fileName.endsWith(".doc")) return "Doc"
    return "File"
  }

  const handleLogin = () => {
    // Simulate login
    setIsAuthenticated(true)
  }

  return (
    <div className="w-full">
      {!isAuthenticated && !compact && (
        <Alert className="mb-4">
          <InfoIcon className="h-4 w-4" />
          <AlertDescription>
            You need to be logged in to upload files. Please{" "}
            <Button variant="link" className="p-0 h-auto font-semibold" onClick={handleLogin}>
              sign in
            </Button>{" "}
            or{" "}
            <Button variant="link" className="p-0 h-auto font-semibold">
              create an account
            </Button>{" "}
            to continue.
          </AlertDescription>
        </Alert>
      )}

      <div
        className={cn(
          "border-2 border-dashed rounded-lg transition-all",
          isDragging ? "border-primary bg-primary/5" : "border-border",
          compact ? "p-4" : "p-8",
          !isAuthenticated && "opacity-75",
        )}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <div className="flex flex-col items-center justify-center text-center">
          <UploadCloud className={cn("text-muted-foreground mb-4", compact ? "h-10 w-10" : "h-16 w-16")} />
          <h3 className={cn("font-semibold", compact ? "text-base" : "text-xl")}>Drag and drop your files here</h3>
          <p className={cn("text-muted-foreground mt-2", compact ? "text-sm" : "text-base")}>
            Upload Figma designs, requirements docs, or test scripts
          </p>
          <div className="mt-4">
            <Button
              as="label"
              htmlFor="file-upload"
              disabled={!isAuthenticated}
              variant={isAuthenticated ? "default" : "outline"}
            >
              Browse Files
              <input
                id="file-upload"
                type="file"
                multiple
                className="sr-only"
                onChange={handleFileChange}
                disabled={!isAuthenticated}
              />
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-2">Supports .fig, .pdf, .md, .js, .ts, and more</p>
        </div>
      </div>

      {files.length > 0 && (
        <div className="mt-4 space-y-2">
          <div className="flex items-center justify-between">
            <h4 className="font-medium">Files to analyze ({files.length})</h4>
            <Button variant="outline" size="sm" onClick={() => setFiles([])} disabled={isUploading || isAnalyzing}>
              Clear All
            </Button>
          </div>

          {isUploading && (
            <div className="space-y-1 my-4">
              <div className="flex justify-between text-sm">
                <span>Uploading files...</span>
                <span>{uploadProgress}%</span>
              </div>
              <Progress value={uploadProgress} className="h-2" />
            </div>
          )}

          {isAnalyzing && (
            <div className="space-y-1 my-4">
              <div className="flex justify-between text-sm">
                <span>Analyzing files...</span>
                <span>Please wait</span>
              </div>
              <Progress value={100} className="h-2" />
            </div>
          )}

          <div className="space-y-2 max-h-60 overflow-y-auto pr-2">
            {files.map((file, index) => (
              <Card key={index} className="p-3 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <FileIcon className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-sm font-medium truncate max-w-[200px] md:max-w-[300px]">{file.name}</p>
                    <p className="text-xs text-muted-foreground">{(file.size / 1024).toFixed(1)} KB</p>
                  </div>
                  <Badge variant="outline" className="ml-2">
                    {getFileTypeLabel(file.name)}
                  </Badge>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => removeFile(index)}
                  disabled={isUploading || isAnalyzing}
                  className="h-8 w-8 p-0"
                >
                  &times;
                </Button>
              </Card>
            ))}
          </div>

          <Button className="w-full mt-4" onClick={startAnalysis} disabled={isUploading || isAnalyzing}>
            {isAnalyzing ? "Analyzing..." : isUploading ? "Uploading..." : "Start Analysis"}
          </Button>
        </div>
      )}
    </div>
  )
}

function cn(...classes: (string | boolean | undefined)[]) {
  return classes.filter(Boolean).join(" ")
}

