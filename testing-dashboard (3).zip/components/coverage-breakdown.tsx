"use client"

import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { CheckCircle2, AlertTriangle, XCircle } from "lucide-react"

interface CoverageItem {
  name: string
  percentage: number
  status: "good" | "warning" | "critical"
}

interface CoverageCategory {
  name: string
  items: CoverageItem[]
}

const mockCoverageData: CoverageCategory[] = [
  {
    name: "Components",
    items: [
      { name: "Login Form", percentage: 95, status: "good" },
      { name: "Dashboard Widgets", percentage: 82, status: "good" },
      { name: "Navigation Menu", percentage: 90, status: "good" },
      { name: "Data Tables", percentage: 78, status: "warning" },
      { name: "Modal Dialogs", percentage: 65, status: "warning" },
      { name: "Form Elements", percentage: 88, status: "good" },
    ],
  },
  {
    name: "Features",
    items: [
      { name: "Authentication", percentage: 92, status: "good" },
      { name: "User Management", percentage: 85, status: "good" },
      { name: "Data Visualization", percentage: 70, status: "warning" },
      { name: "File Upload", percentage: 60, status: "warning" },
      { name: "Search Functionality", percentage: 45, status: "critical" },
      { name: "Notifications", percentage: 75, status: "warning" },
    ],
  },
  {
    name: "Responsiveness",
    items: [
      { name: "Desktop", percentage: 95, status: "good" },
      { name: "Tablet", percentage: 80, status: "good" },
      { name: "Mobile", percentage: 62, status: "warning" },
      { name: "Small Mobile", percentage: 40, status: "critical" },
    ],
  },
]

export function CoverageBreakdown() {
  const getStatusIcon = (status: CoverageItem["status"]) => {
    switch (status) {
      case "good":
        return <CheckCircle2 className="h-4 w-4 text-green-500" />
      case "warning":
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />
      case "critical":
        return <XCircle className="h-4 w-4 text-red-500" />
    }
  }

  const getStatusBadge = (percentage: number) => {
    if (percentage >= 80) {
      return (
        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
          Good
        </Badge>
      )
    } else if (percentage >= 60) {
      return (
        <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
          Needs Improvement
        </Badge>
      )
    } else {
      return (
        <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
          Critical
        </Badge>
      )
    }
  }

  return (
    <Tabs defaultValue="Components">
      <TabsList className="mb-4">
        {mockCoverageData.map((category) => (
          <TabsTrigger key={category.name} value={category.name}>
            {category.name}
          </TabsTrigger>
        ))}
      </TabsList>

      {mockCoverageData.map((category) => (
        <TabsContent key={category.name} value={category.name} className="space-y-4">
          {category.items.map((item) => (
            <div key={item.name} className="space-y-1">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {getStatusIcon(item.status)}
                  <span className="font-medium text-sm">{item.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  {getStatusBadge(item.percentage)}
                  <span className="text-sm font-medium">{item.percentage}%</span>
                </div>
              </div>
              <Progress
                value={item.percentage}
                className="h-2"
                indicatorClassName={
                  item.percentage >= 80 ? "bg-green-500" : item.percentage >= 60 ? "bg-yellow-500" : "bg-red-500"
                }
              />
            </div>
          ))}
        </TabsContent>
      ))}
    </Tabs>
  )
}

