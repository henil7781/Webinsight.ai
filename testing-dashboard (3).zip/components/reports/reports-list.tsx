"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowUpRight, BarChart2, Search, Shield } from "lucide-react"
import Link from "next/link"

interface Report {
  id: string
  url: string
  date: string
  seoScore: number
  performanceScore: number
  securityScore: number
}

const mockReports: Report[] = [
  {
    id: "rep-1",
    url: "example.com",
    date: "May 15, 2023",
    seoScore: 78,
    performanceScore: 85,
    securityScore: 92,
  },
  {
    id: "rep-2",
    url: "mywebsite.com",
    date: "May 10, 2023",
    seoScore: 65,
    performanceScore: 72,
    securityScore: 88,
  },
  {
    id: "rep-3",
    url: "anothersite.org",
    date: "May 5, 2023",
    seoScore: 82,
    performanceScore: 79,
    securityScore: 95,
  },
  {
    id: "rep-4",
    url: "testsite.net",
    date: "April 28, 2023",
    seoScore: 71,
    performanceScore: 68,
    securityScore: 84,
  },
  {
    id: "rep-5",
    url: "example.com",
    date: "April 15, 2023",
    seoScore: 73,
    performanceScore: 80,
    securityScore: 90,
  },
]

export function ReportsList() {
  const getScoreBadge = (score: number) => {
    if (score >= 80) {
      return <Badge className="bg-green-500">Good</Badge>
    } else if (score >= 60) {
      return (
        <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
          Needs Improvement
        </Badge>
      )
    } else {
      return (
        <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
          Poor
        </Badge>
      )
    }
  }

  return (
    <div className="space-y-4">
      {mockReports.map((report) => (
        <Card key={report.id}>
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h3 className="font-medium">{report.url}</h3>
                  <Badge variant="outline">Analyzed: {report.date}</Badge>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                  <div className="flex items-center gap-2">
                    <Search className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">SEO: {report.seoScore}/100</span>
                    {getScoreBadge(report.seoScore)}
                  </div>
                  <div className="flex items-center gap-2">
                    <BarChart2 className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">Performance: {report.performanceScore}/100</span>
                    {getScoreBadge(report.performanceScore)}
                  </div>
                  <div className="flex items-center gap-2">
                    <Shield className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">Security: {report.securityScore}/100</span>
                    {getScoreBadge(report.securityScore)}
                  </div>
                </div>
              </div>
              <div className="flex gap-2 md:flex-col">
                <Button variant="outline" size="sm" asChild>
                  <Link href={`/dashboard/reports/${report.id}`}>
                    View Report
                    <ArrowUpRight className="ml-1 h-3 w-3" />
                  </Link>
                </Button>
                <Button size="sm" asChild>
                  <Link href={`/dashboard/analyze?url=${report.url}`}>Analyze Again</Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

