"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { SeoResults } from "@/components/analyze/seo-results"
import { PerformanceResults } from "@/components/analyze/performance-results"
import { SecurityResults } from "@/components/analyze/security-results"

interface ReportDetailsProps {
  id: string
}

export function ReportDetails({ id }: ReportDetailsProps) {
  // Mock data - in a real app, this would come from the API based on the ID
  const report = {
    id,
    url: "example.com",
    date: "May 15, 2023",
    seoScore: 78,
    performanceScore: 85,
    securityScore: 92,
  }

  const getScoreBadge = (score: number) => {
    if (score >= 80) {
      return <Badge className="bg-green-500">Good</Badge>
    } else if (score >= 60) {
      return (
        <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
          Needs Improvement
        </Badge>
      )
    } else {
      return (
        <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
          Poor
        </Badge>
      )
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Analysis Report for {report.url}</CardTitle>
          <CardDescription>Analysis completed on {report.date}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">SEO Score</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center">
                  <div className="relative flex h-32 w-32 items-center justify-center rounded-full">
                    <svg className="h-32 w-32">
                      <circle
                        className="text-muted stroke-current"
                        strokeWidth="12"
                        cx="64"
                        cy="64"
                        r="56"
                        fill="none"
                      />
                      <circle
                        className="text-primary stroke-current"
                        strokeWidth="12"
                        strokeLinecap="round"
                        cx="64"
                        cy="64"
                        r="56"
                        fill="none"
                        strokeDasharray="350"
                        strokeDashoffset={350 - (350 * report.seoScore) / 100}
                      />
                    </svg>
                    <span className="absolute text-2xl font-bold">{report.seoScore}</span>
                  </div>
                  <div className="mt-4 flex items-center gap-2">{getScoreBadge(report.seoScore)}</div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Performance Score</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center">
                  <div className="relative flex h-32 w-32 items-center justify-center rounded-full">
                    <svg className="h-32 w-32">
                      <circle
                        className="text-muted stroke-current"
                        strokeWidth="12"
                        cx="64"
                        cy="64"
                        r="56"
                        fill="none"
                      />
                      <circle
                        className="text-primary stroke-current"
                        strokeWidth="12"
                        strokeLinecap="round"
                        cx="64"
                        cy="64"
                        r="56"
                        fill="none"
                        strokeDasharray="350"
                        strokeDashoffset={350 - (350 * report.performanceScore) / 100}
                      />
                    </svg>
                    <span className="absolute text-2xl font-bold">{report.performanceScore}</span>
                  </div>
                  <div className="mt-4 flex items-center gap-2">{getScoreBadge(report.performanceScore)}</div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Security Score</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center">
                  <div className="relative flex h-32 w-32 items-center justify-center rounded-full">
                    <svg className="h-32 w-32">
                      <circle
                        className="text-muted stroke-current"
                        strokeWidth="12"
                        cx="64"
                        cy="64"
                        r="56"
                        fill="none"
                      />
                      <circle
                        className="text-primary stroke-current"
                        strokeWidth="12"
                        strokeLinecap="round"
                        cx="64"
                        cy="64"
                        r="56"
                        fill="none"
                        strokeDasharray="350"
                        strokeDashoffset={350 - (350 * report.securityScore) / 100}
                      />
                    </svg>
                    <span className="absolute text-2xl font-bold">{report.securityScore}</span>
                  </div>
                  <div className="mt-4 flex items-center gap-2">{getScoreBadge(report.securityScore)}</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="seo" className="space-y-4">
        <TabsList>
          <TabsTrigger value="seo">SEO Analysis</TabsTrigger>
          <TabsTrigger value="performance">Performance Analysis</TabsTrigger>
          <TabsTrigger value="security">Security Analysis</TabsTrigger>
        </TabsList>
        <TabsContent value="seo">
          <SeoResults />
        </TabsContent>
        <TabsContent value="performance">
          <PerformanceResults />
        </TabsContent>
        <TabsContent value="security">
          <SecurityResults />
        </TabsContent>
      </Tabs>
    </div>
  )
}

