"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import {
  FileIcon,
  FileTextIcon,
  ImageIcon,
  FileCode2Icon,
  AlertCircleIcon,
  CheckCircleIcon,
  ClockIcon,
} from "lucide-react"

type FileStatus = "analyzing" | "completed" | "failed" | "queued"

interface UploadedFile {
  id: string
  name: string
  type: string
  size: string
  uploadedAt: string
  status: FileStatus
  progress?: number
  issues?: number
}

const mockUploads: UploadedFile[] = [
  {
    id: "file-1",
    name: "dashboard-design.fig",
    type: "figma",
    size: "4.2 MB",
    uploadedAt: "10 minutes ago",
    status: "completed",
    issues: 3,
  },
  {
    id: "file-2",
    name: "login-form.jsx",
    type: "code",
    size: "12 KB",
    uploadedAt: "25 minutes ago",
    status: "completed",
    issues: 0,
  },
  {
    id: "file-3",
    name: "user-flow-diagram.png",
    type: "image",
    size: "1.8 MB",
    uploadedAt: "1 hour ago",
    status: "analyzing",
    progress: 65,
  },
  {
    id: "file-4",
    name: "api-tests.js",
    type: "code",
    size: "28 KB",
    uploadedAt: "2 hours ago",
    status: "failed",
  },
  {
    id: "file-5",
    name: "requirements.md",
    type: "document",
    size: "45 KB",
    uploadedAt: "3 hours ago",
    status: "queued",
  },
]

export function RecentUploads() {
  const [uploads, setUploads] = useState<UploadedFile[]>(mockUploads)

  const getFileIcon = (type: string) => {
    switch (type) {
      case "figma":
        return <FileIcon className="h-5 w-5 text-purple-500" />
      case "code":
        return <FileCode2Icon className="h-5 w-5 text-blue-500" />
      case "image":
        return <ImageIcon className="h-5 w-5 text-green-500" />
      case "document":
        return <FileTextIcon className="h-5 w-5 text-yellow-500" />
      default:
        return <FileIcon className="h-5 w-5 text-gray-500" />
    }
  }

  const getStatusBadge = (status: FileStatus) => {
    switch (status) {
      case "analyzing":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Analyzing
          </Badge>
        )
      case "completed":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Completed
          </Badge>
        )
      case "failed":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            Failed
          </Badge>
        )
      case "queued":
        return (
          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
            Queued
          </Badge>
        )
    }
  }

  const getStatusIcon = (status: FileStatus, issues?: number) => {
    switch (status) {
      case "analyzing":
        return <ClockIcon className="h-5 w-5 text-blue-500" />
      case "completed":
        return issues && issues > 0 ? (
          <AlertCircleIcon className="h-5 w-5 text-yellow-500" />
        ) : (
          <CheckCircleIcon className="h-5 w-5 text-green-500" />
        )
      case "failed":
        return <AlertCircleIcon className="h-5 w-5 text-red-500" />
      case "queued":
        return <ClockIcon className="h-5 w-5 text-yellow-500" />
    }
  }

  return (
    <div className="space-y-4">
      {uploads.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-muted-foreground">No files have been uploaded yet</p>
        </div>
      ) : (
        uploads.map((file) => (
          <Card key={file.id} className="p-4">
            <div className="flex flex-col sm:flex-row sm:items-center gap-4">
              <div className="flex items-center gap-3 min-w-0">
                {getFileIcon(file.type)}
                <div className="min-w-0">
                  <p className="font-medium truncate">{file.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {file.size} • {file.uploadedAt}
                  </p>
                </div>
              </div>

              <div className="sm:ml-auto flex flex-col sm:flex-row sm:items-center gap-3">
                {file.status === "analyzing" && (
                  <div className="w-full sm:w-32">
                    <Progress value={file.progress} className="h-2" />
                    <p className="text-xs text-muted-foreground text-right mt-1">{file.progress}% complete</p>
                  </div>
                )}

                <div className="flex items-center gap-2">
                  {getStatusBadge(file.status)}
                  {file.status === "completed" && file.issues !== undefined && (
                    <Badge
                      variant={file.issues > 0 ? "default" : "outline"}
                      className={file.issues > 0 ? "bg-yellow-500" : "bg-green-50 text-green-700 border-green-200"}
                    >
                      {file.issues} {file.issues === 1 ? "issue" : "issues"}
                    </Badge>
                  )}
                </div>

                <Button variant="outline" size="sm">
                  View Results
                </Button>
              </div>
            </div>
          </Card>
        ))
      )}
    </div>
  )
}

