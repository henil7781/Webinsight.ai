"use client"

import React from "react"

import { useTheme } from "next-themes"
import { useEffect, useState } from "react"

export function LineChart() {
  const { theme } = useTheme()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return <div className="flex h-[250px] w-full items-center justify-center bg-muted/10">Loading chart...</div>
  }

  // Mock data for the line chart
  const data = [
    { month: "Jan", seo: 65, performance: 70, security: 80 },
    { month: "Feb", seo: 68, performance: 72, security: 82 },
    { month: "Mar", seo: 70, performance: 75, security: 85 },
    { month: "Apr", seo: 73, performance: 78, security: 87 },
    { month: "May", seo: 76, performance: 80, security: 89 },
    { month: "Jun", seo: 78, performance: 82, security: 90 },
  ]

  // Determine colors based on theme
  const textColor = theme === "dark" ? "#e0e0e0" : "#333333"
  const gridColor = theme === "dark" ? "#444444" : "#e0e0e0"
  const seoColor = "#3b82f6"
  const performanceColor = "#10b981"
  const securityColor = "#8b5cf6"

  return (
    <div className="h-full w-full">
      <svg width="100%" height="100%" viewBox="0 0 800 250" preserveAspectRatio="xMidYMid meet">
        {/* X and Y axes */}
        <line x1="50" y1="220" x2="750" y2="220" stroke={gridColor} strokeWidth="1" />
        <line x1="50" y1="30" x2="50" y2="220" stroke={gridColor} strokeWidth="1" />

        {/* X-axis labels */}
        {data.map((item, index) => (
          <text
            key={`x-label-${index}`}
            x={50 + (index * 700) / (data.length - 1)}
            y="240"
            textAnchor="middle"
            fill={textColor}
            fontSize="12"
          >
            {item.month}
          </text>
        ))}

        {/* Y-axis labels */}
        {[0, 25, 50, 75, 100].map((value, index) => (
          <text
            key={`y-label-${index}`}
            x="40"
            y={220 - (value * 190) / 100}
            textAnchor="end"
            fill={textColor}
            fontSize="12"
          >
            {value}
          </text>
        ))}

        {/* Grid lines */}
        {[25, 50, 75, 100].map((value, index) => (
          <line
            key={`grid-${index}`}
            x1="50"
            y1={220 - (value * 190) / 100}
            x2="750"
            y2={220 - (value * 190) / 100}
            stroke={gridColor}
            strokeWidth="0.5"
            strokeDasharray="5,5"
          />
        ))}

        {/* SEO Line */}
        <path
          d={data
            .map((item, index) => {
              const x = 50 + (index * 700) / (data.length - 1)
              const y = 220 - (item.seo * 190) / 100
              return index === 0 ? `M ${x} ${y}` : `L ${x} ${y}`
            })
            .join(" ")}
          fill="none"
          stroke={seoColor}
          strokeWidth="2"
        />

        {/* Performance Line */}
        <path
          d={data
            .map((item, index) => {
              const x = 50 + (index * 700) / (data.length - 1)
              const y = 220 - (item.performance * 190) / 100
              return index === 0 ? `M ${x} ${y}` : `L ${x} ${y}`
            })
            .join(" ")}
          fill="none"
          stroke={performanceColor}
          strokeWidth="2"
        />

        {/* Security Line */}
        <path
          d={data
            .map((item, index) => {
              const x = 50 + (index * 700) / (data.length - 1)
              const y = 220 - (item.security * 190) / 100
              return index === 0 ? `M ${x} ${y}` : `L ${x} ${y}`
            })
            .join(" ")}
          fill="none"
          stroke={securityColor}
          strokeWidth="2"
        />

        {/* Data points */}
        {data.map((item, index) => (
          <React.Fragment key={`points-${index}`}>
            <circle
              cx={50 + (index * 700) / (data.length - 1)}
              cy={220 - (item.seo * 190) / 100}
              r="4"
              fill={seoColor}
            />
            <circle
              cx={50 + (index * 700) / (data.length - 1)}
              cy={220 - (item.performance * 190) / 100}
              r="4"
              fill={performanceColor}
            />
            <circle
              cx={50 + (index * 700) / (data.length - 1)}
              cy={220 - (item.security * 190) / 100}
              r="4"
              fill={securityColor}
            />
          </React.Fragment>
        ))}

        {/* Legend */}
        <circle cx="600" cy="30" r="4" fill={seoColor} />
        <text x="610" y="35" fill={textColor} fontSize="12">
          SEO
        </text>
        <circle cx="650" cy="30" r="4" fill={performanceColor} />
        <text x="660" y="35" fill={textColor} fontSize="12">
          Performance
        </text>
        <circle cx="740" cy="30" r="4" fill={securityColor} />
        <text x="750" y="35" fill={textColor} fontSize="12">
          Security
        </text>
      </svg>
    </div>
  )
}

export function BarChart() {
  const { theme } = useTheme()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return <div className="flex h-[250px] w-full items-center justify-center bg-muted/10">Loading chart...</div>
  }

  // Mock data for the bar chart
  const data = [
    { category: "SEO", value: 78 },
    { category: "Performance", value: 85 },
    { category: "Security", value: 92 },
    { category: "Accessibility", value: 65 },
    { category: "Best Practices", value: 80 },
  ]

  // Determine colors based on theme
  const textColor = theme === "dark" ? "#e0e0e0" : "#333333"
  const gridColor = theme === "dark" ? "#444444" : "#e0e0e0"
  const barColors = ["#3b82f6", "#10b981", "#8b5cf6", "#f59e0b", "#ef4444"]

  const barWidth = 80
  const barSpacing = 40
  const chartWidth = data.length * (barWidth + barSpacing)

  return (
    <div className="h-full w-full">
      <svg
        width="100%"
        height="100%"
        viewBox={`0 0 ${Math.max(800, chartWidth)} 250`}
        preserveAspectRatio="xMidYMid meet"
      >
        {/* X and Y axes */}
        <line x1="50" y1="220" x2={Math.max(750, chartWidth + 50)} y2="220" stroke={gridColor} strokeWidth="1" />
        <line x1="50" y1="30" x2="50" y2="220" stroke={gridColor} strokeWidth="1" />

        {/* Y-axis labels */}
        {[0, 25, 50, 75, 100].map((value, index) => (
          <text
            key={`y-label-${index}`}
            x="40"
            y={220 - (value * 190) / 100}
            textAnchor="end"
            fill={textColor}
            fontSize="12"
          >
            {value}
          </text>
        ))}

        {/* Grid lines */}
        {[25, 50, 75, 100].map((value, index) => (
          <line
            key={`grid-${index}`}
            x1="50"
            y1={220 - (value * 190) / 100}
            x2={Math.max(750, chartWidth + 50)}
            y2={220 - (value * 190) / 100}
            stroke={gridColor}
            strokeWidth="0.5"
            strokeDasharray="5,5"
          />
        ))}

        {/* Bars */}
        {data.map((item, index) => {
          const x = 50 + index * (barWidth + barSpacing) + barSpacing / 2
          const barHeight = (item.value * 190) / 100
          return (
            <g key={`bar-${index}`}>
              <rect
                x={x}
                y={220 - barHeight}
                width={barWidth}
                height={barHeight}
                fill={barColors[index % barColors.length]}
                rx="4"
              />
              <text x={x + barWidth / 2} y="235" textAnchor="middle" fill={textColor} fontSize="12">
                {item.category}
              </text>
              <text
                x={x + barWidth / 2}
                y={220 - barHeight - 5}
                textAnchor="middle"
                fill={textColor}
                fontSize="12"
                fontWeight="bold"
              >
                {item.value}
              </text>
            </g>
          )
        })}
      </svg>
    </div>
  )
}

