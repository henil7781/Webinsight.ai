"use client"

import { useRef, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface CoverageChartProps {
  expanded?: boolean
}

interface CoverageData {
  category: string
  percentage: number
  color: string
}

const mockCoverageData: CoverageData[] = [
  { category: "UI Components", percentage: 82, color: "#3b82f6" },
  { category: "API Endpoints", percentage: 68, color: "#10b981" },
  { category: "User Flows", percentage: 76, color: "#8b5cf6" },
  { category: "Edge Cases", percentage: 45, color: "#f59e0b" },
  { category: "Mobile Views", percentage: 62, color: "#ef4444" },
]

export function CoverageChart({ expanded = false }: CoverageChartProps) {
  const chartRef = useRef<HTMLDivElement>(null)
  const [activeCategory, setActiveCategory] = useState<string | null>(null)

  const renderBarChart = () => {
    return (
      <div className="mt-4 space-y-4">
        {mockCoverageData.map((item) => (
          <div
            key={item.category}
            className="space-y-1"
            onMouseEnter={() => setActiveCategory(item.category)}
            onMouseLeave={() => setActiveCategory(null)}
          >
            <div className="flex justify-between text-sm">
              <span className="font-medium">{item.category}</span>
              <span className="text-muted-foreground">{item.percentage}%</span>
            </div>
            <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{
                  width: `${item.percentage}%`,
                  backgroundColor: item.color,
                  opacity: activeCategory === item.category ? 1 : 0.8,
                }}
              />
            </div>
          </div>
        ))}
      </div>
    )
  }

  const renderDetailedView = () => {
    const totalCoverage = mockCoverageData.reduce((acc, item) => acc + item.percentage, 0) / mockCoverageData.length

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h3 className="text-lg font-medium mb-4">Coverage by Category</h3>
          {renderBarChart()}
        </div>
        <div>
          <h3 className="text-lg font-medium mb-4">Coverage Summary</h3>
          <div className="space-y-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Overall Coverage</span>
                  <span className="text-2xl font-bold">{totalCoverage.toFixed(1)}%</span>
                </div>
                <div className="h-2 w-full bg-muted rounded-full overflow-hidden mt-2">
                  <div className="h-full rounded-full bg-primary" style={{ width: `${totalCoverage}%` }} />
                </div>
              </CardContent>
            </Card>

            <div className="space-y-2">
              <h4 className="text-sm font-medium">Coverage Gaps</h4>
              <div className="space-y-2">
                {mockCoverageData
                  .filter((item) => item.percentage < 70)
                  .map((item) => (
                    <div key={item.category} className="flex items-center justify-between p-2 rounded-md bg-muted">
                      <span className="text-sm">{item.category}</span>
                      <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                        {item.percentage}% (Low)
                      </Badge>
                    </div>
                  ))}
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="text-sm font-medium">Recommendations</h4>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>• Add more tests for Edge Cases (currently at 45%)</li>
                <li>• Improve Mobile Views testing coverage (currently at 62%)</li>
                <li>• Focus on API Endpoints with critical functionality</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div ref={chartRef} className="w-full">
      {expanded ? renderDetailedView() : renderBarChart()}
    </div>
  )
}

