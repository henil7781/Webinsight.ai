import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

export function HeroSection() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48">
      <div className="container px-4 md:px-6">
        <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
          <div className="flex flex-col justify-center space-y-4">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none">
                Analyze Your Website with AI
              </h1>
              <p className="max-w-[600px] text-muted-foreground md:text-xl">
                Get comprehensive insights on SEO, performance, and security. Improve your website with AI-powered
                recommendations.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Button asChild size="lg">
                <Link href="/register">
                  Get Started
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <Link href="/login">Sign In</Link>
              </Button>
            </div>
          </div>
          <div className="flex items-center justify-center">
            <div className="relative h-[350px] w-full md:h-[450px] lg:h-[450px] xl:h-[550px]">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg shadow-2xl overflow-hidden">
                <div className="absolute inset-0 bg-grid-white/10 bg-grid-8 [mask-image:linear-gradient(to_bottom,white,transparent)]"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="bg-white/90 dark:bg-gray-950/90 p-6 rounded-lg shadow-lg max-w-md">
                    <div className="space-y-2">
                      <div className="h-2 w-24 bg-blue-500 rounded"></div>
                      <div className="h-2 w-32 bg-blue-300 rounded"></div>
                      <div className="h-2 w-20 bg-blue-400 rounded"></div>
                    </div>
                    <div className="mt-6 space-y-4">
                      <div className="flex items-center gap-4">
                        <div className="h-10 w-10 rounded-full bg-green-500 flex items-center justify-center text-white font-bold">
                          92
                        </div>
                        <div className="space-y-1 flex-1">
                          <div className="h-2 w-24 bg-green-500 rounded"></div>
                          <div className="h-2 w-32 bg-gray-200 dark:bg-gray-700 rounded"></div>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="h-10 w-10 rounded-full bg-yellow-500 flex items-center justify-center text-white font-bold">
                          78
                        </div>
                        <div className="space-y-1 flex-1">
                          <div className="h-2 w-24 bg-yellow-500 rounded"></div>
                          <div className="h-2 w-32 bg-gray-200 dark:bg-gray-700 rounded"></div>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="h-10 w-10 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold">
                          85
                        </div>
                        <div className="space-y-1 flex-1">
                          <div className="h-2 w-24 bg-blue-500 rounded"></div>
                          <div className="h-2 w-32 bg-gray-200 dark:bg-gray-700 rounded"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

