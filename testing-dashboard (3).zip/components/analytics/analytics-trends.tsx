"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart } from "@/components/ui/charts"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useState } from "react"

export function AnalyticsTrends() {
  const [timeRange, setTimeRange] = useState("30days")

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-lg font-medium">Performance Trends</h3>
          <p className="text-sm text-muted-foreground">Track how your metrics change over time</p>
        </div>
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select time range" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7days">Last 7 days</SelectItem>
            <SelectItem value="30days">Last 30 days</SelectItem>
            <SelectItem value="90days">Last 90 days</SelectItem>
            <SelectItem value="year">Last year</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Visitors Trend</CardTitle>
          <CardDescription>Daily visitor count over time</CardDescription>
        </CardHeader>
        <CardContent className="h-[300px]">
          <LineChart />
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>SEO Performance</CardTitle>
            <CardDescription>Keyword rankings and organic traffic</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            <LineChart />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Conversion Rates</CardTitle>
            <CardDescription>Conversion metrics over time</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            <LineChart />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Top Growing Pages</CardTitle>
          <CardDescription>Pages with the highest growth in traffic</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { page: "/blog/seo-tips", growth: "+128%", visits: 3245 },
              { page: "/products/new-release", growth: "+86%", visits: 2876 },
              { page: "/services/consulting", growth: "+64%", visits: 1932 },
              { page: "/case-studies", growth: "+52%", visits: 1654 },
              { page: "/resources/guides", growth: "+43%", visits: 1287 },
            ].map((item, index) => (
              <div
                key={index}
                className="flex flex-col sm:flex-row sm:items-center justify-between p-3 border rounded-lg"
              >
                <div className="font-medium mb-2 sm:mb-0">{item.page}</div>
                <div className="flex flex-wrap gap-4 text-sm">
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">Growth</span>
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      {item.growth}
                    </Badge>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">Visits</span>
                    <span className="font-medium">{item.visits.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

