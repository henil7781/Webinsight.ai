"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart } from "@/components/ui/charts"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

export function AnalyticsOverview() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      <Card className="col-span-full">
        <CardHeader>
          <CardTitle>Performance Overview</CardTitle>
          <CardDescription>Website performance metrics over the last 30 days</CardDescription>
        </CardHeader>
        <CardContent className="h-[300px]">
          <LineChart />
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Total Visitors</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">24,892</div>
          <div className="flex items-center mt-1">
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
              +12.5%
            </Badge>
            <span className="text-xs text-muted-foreground ml-2">vs. previous period</span>
          </div>
          <div className="mt-4">
            <div className="flex justify-between text-xs mb-1">
              <span>Progress to goal</span>
              <span>83%</span>
            </div>
            <Progress value={83} className="h-2" />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Avg. Session Duration</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">3m 42s</div>
          <div className="flex items-center mt-1">
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
              +8.3%
            </Badge>
            <span className="text-xs text-muted-foreground ml-2">vs. previous period</span>
          </div>
          <div className="mt-4">
            <div className="flex justify-between text-xs mb-1">
              <span>Progress to goal</span>
              <span>76%</span>
            </div>
            <Progress value={76} className="h-2" />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Bounce Rate</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">32.8%</div>
          <div className="flex items-center mt-1">
            <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
              +2.1%
            </Badge>
            <span className="text-xs text-muted-foreground ml-2">vs. previous period</span>
          </div>
          <div className="mt-4">
            <div className="flex justify-between text-xs mb-1">
              <span>Goal: below 30%</span>
              <span>91%</span>
            </div>
            <Progress value={91} className="h-2" />
          </div>
        </CardContent>
      </Card>

      <Card className="col-span-full">
        <CardHeader>
          <CardTitle>Traffic by Page</CardTitle>
          <CardDescription>Most visited pages on your website</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { page: "/", visits: 8432, bounce: "28.3%", duration: "2m 13s" },
              { page: "/products", visits: 6218, bounce: "32.1%", duration: "3m 42s" },
              { page: "/blog", visits: 4129, bounce: "25.8%", duration: "4m 17s" },
              { page: "/about", visits: 2983, bounce: "41.2%", duration: "1m 34s" },
              { page: "/contact", visits: 1876, bounce: "22.6%", duration: "2m 58s" },
            ].map((item, index) => (
              <div
                key={index}
                className="flex flex-col sm:flex-row sm:items-center justify-between p-3 border rounded-lg"
              >
                <div className="font-medium mb-2 sm:mb-0">{item.page}</div>
                <div className="flex flex-wrap gap-4 text-sm">
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">Visits</span>
                    <span className="font-medium">{item.visits.toLocaleString()}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">Bounce Rate</span>
                    <span className="font-medium">{item.bounce}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">Avg. Duration</span>
                    <span className="font-medium">{item.duration}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

