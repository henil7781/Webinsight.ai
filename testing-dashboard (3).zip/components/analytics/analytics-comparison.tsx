"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart } from "@/components/ui/charts"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useState } from "react"

export function AnalyticsComparison() {
  const [compareWith, setCompareWith] = useState("previous")

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-lg font-medium">Performance Comparison</h3>
          <p className="text-sm text-muted-foreground">Compare current metrics with previous periods</p>
        </div>
        <Select value={compareWith} onValueChange={setCompareWith}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Compare with" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="previous">Previous period</SelectItem>
            <SelectItem value="year">Same period last year</SelectItem>
            <SelectItem value="best">Best performing period</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Metrics Comparison</CardTitle>
          <CardDescription>Current vs previous period</CardDescription>
        </CardHeader>
        <CardContent className="h-[400px]">
          <BarChart />
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Visitors</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-center">
              <div>
                <div className="text-2xl font-bold">24,892</div>
                <div className="text-sm text-muted-foreground">Current</div>
              </div>
              <div className="text-right">
                <div className="text-xl font-medium">22,123</div>
                <div className="text-sm text-muted-foreground">Previous</div>
              </div>
            </div>
            <div className="mt-4 flex items-center justify-center">
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                +12.5%
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Page Views</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-center">
              <div>
                <div className="text-2xl font-bold">67,432</div>
                <div className="text-sm text-muted-foreground">Current</div>
              </div>
              <div className="text-right">
                <div className="text-xl font-medium">58,976</div>
                <div className="text-sm text-muted-foreground">Previous</div>
              </div>
            </div>
            <div className="mt-4 flex items-center justify-center">
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                +14.3%
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Avg. Session</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-center">
              <div>
                <div className="text-2xl font-bold">3m 42s</div>
                <div className="text-sm text-muted-foreground">Current</div>
              </div>
              <div className="text-right">
                <div className="text-xl font-medium">3m 26s</div>
                <div className="text-sm text-muted-foreground">Previous</div>
              </div>
            </div>
            <div className="mt-4 flex items-center justify-center">
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                +8.3%
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Bounce Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-center">
              <div>
                <div className="text-2xl font-bold">32.8%</div>
                <div className="text-sm text-muted-foreground">Current</div>
              </div>
              <div className="text-right">
                <div className="text-xl font-medium">30.7%</div>
                <div className="text-sm text-muted-foreground">Previous</div>
              </div>
            </div>
            <div className="mt-4 flex items-center justify-center">
              <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                +2.1%
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

