"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { CheckCircle2, ChevronDown, ChevronRight, Clock, XCircle } from "lucide-react"

interface TestCaseTableProps {
  expanded?: boolean
  filterType?: TestType
}

type TestStatus = "passed" | "failed" | "pending"
type TestType = "UI" | "Functional" | "Integration" | "E2E"
type TestPriority = "high" | "medium" | "low"

interface TestCase {
  id: string
  name: string
  status: TestStatus
  type: TestType
  priority: TestPriority
  createdAt: string
  description?: string
  source?: string
}

const mockTestCases: TestCase[] = [
  {
    id: "TC-001",
    name: "Login Form Validation",
    status: "passed",
    type: "UI",
    priority: "high",
    createdAt: "2023-03-28",
    description: "Validates that the login form correctly handles input validation for email and password fields.",
    source: "dashboard-design.fig",
  },
  {
    id: "TC-002",
    name: "Dashboard Loading States",
    status: "failed",
    type: "UI",
    priority: "medium",
    createdAt: "2023-03-27",
    description: "Verifies that loading states are properly displayed when dashboard data is being fetched.",
    source: "dashboard-design.fig",
  },
  {
    id: "TC-003",
    name: "User Authentication Flow",
    status: "passed",
    type: "Functional",
    priority: "high",
    createdAt: "2023-03-26",
    description: "Tests the complete user authentication flow including login, session management, and logout.",
    source: "login-form.jsx",
  },
  {
    id: "TC-004",
    name: "Data Visualization Rendering",
    status: "pending",
    type: "UI",
    priority: "medium",
    createdAt: "2023-03-25",
    description: "Checks if data visualization components render correctly with different datasets.",
    source: "dashboard-design.fig",
  },
  {
    id: "TC-005",
    name: "API Integration Tests",
    status: "passed",
    type: "Integration",
    priority: "high",
    createdAt: "2023-03-24",
    description:
      "Verifies that the application correctly integrates with external APIs and handles responses appropriately.",
    source: "api-tests.js",
  },
  {
    id: "TC-006",
    name: "Mobile Responsiveness",
    status: "failed",
    type: "UI",
    priority: "high",
    createdAt: "2023-03-23",
    description: "Tests the application's responsiveness across different mobile device viewports.",
    source: "user-flow-diagram.png",
  },
  {
    id: "TC-007",
    name: "Form Submission Flow",
    status: "passed",
    type: "Functional",
    priority: "medium",
    createdAt: "2023-03-22",
    description:
      "Validates the complete form submission flow including validation, submission, and success/error states.",
    source: "login-form.jsx",
  },
  {
    id: "TC-008",
    name: "End-to-End User Journey",
    status: "pending",
    type: "E2E",
    priority: "high",
    createdAt: "2023-03-21",
    description: "Tests the complete user journey from registration to performing key actions within the application.",
    source: "requirements.md",
  },
]

export function TestCaseTable({ expanded = false, filterType }: TestCaseTableProps) {
  const [expandedRows, setExpandedRows] = useState<Record<string, boolean>>({})

  const toggleRow = (id: string) => {
    setExpandedRows((prev) => ({
      ...prev,
      [id]: !prev[id],
    }))
  }

  const getStatusIcon = (status: TestStatus) => {
    switch (status) {
      case "passed":
        return <CheckCircle2 className="h-4 w-4 text-green-500" />
      case "failed":
        return <XCircle className="h-4 w-4 text-red-500" />
      case "pending":
        return <Clock className="h-4 w-4 text-yellow-500" />
    }
  }

  const getStatusBadge = (status: TestStatus) => {
    switch (status) {
      case "passed":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Passed
          </Badge>
        )
      case "failed":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            Failed
          </Badge>
        )
      case "pending":
        return (
          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
            Pending
          </Badge>
        )
    }
  }

  const getPriorityBadge = (priority: TestPriority) => {
    switch (priority) {
      case "high":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            High
          </Badge>
        )
      case "medium":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Medium
          </Badge>
        )
      case "low":
        return (
          <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
            Low
          </Badge>
        )
    }
  }

  const filteredTests = filterType ? mockTestCases.filter((test) => test.type === filterType) : mockTestCases

  const displayedTests = expanded ? filteredTests : filteredTests.slice(0, 5)

  return (
    <Table>
      <TableHeader>
        <TableRow>
          {expanded && <TableHead className="w-10"></TableHead>}
          <TableHead className="w-[100px]">ID</TableHead>
          <TableHead>Test Name</TableHead>
          <TableHead className="w-[100px]">Status</TableHead>
          {expanded && (
            <>
              <TableHead>Type</TableHead>
              <TableHead>Priority</TableHead>
              <TableHead>Created</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </>
          )}
        </TableRow>
      </TableHeader>
      <TableBody>
        {displayedTests.map((test) => (
          <>
            <TableRow key={test.id}>
              {expanded && (
                <TableCell>
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => toggleRow(test.id)}>
                    {expandedRows[test.id] ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                  </Button>
                </TableCell>
              )}
              <TableCell className="font-medium">{test.id}</TableCell>
              <TableCell>{test.name}</TableCell>
              <TableCell>
                <div className="flex items-center gap-2">
                  {getStatusIcon(test.status)}
                  {expanded && getStatusBadge(test.status)}
                </div>
              </TableCell>
              {expanded && (
                <>
                  <TableCell>
                    <Badge variant="outline">{test.type}</Badge>
                  </TableCell>
                  <TableCell>{getPriorityBadge(test.priority)}</TableCell>
                  <TableCell>{test.createdAt}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="outline" size="sm">
                      Run
                    </Button>
                  </TableCell>
                </>
              )}
            </TableRow>
            {expanded && expandedRows[test.id] && (
              <TableRow>
                <TableCell colSpan={8} className="bg-muted/50">
                  <div className="p-2">
                    <h4 className="font-medium mb-1">Description:</h4>
                    <p className="text-sm text-muted-foreground">{test.description}</p>
                    {test.source && (
                      <div className="mt-2">
                        <h4 className="font-medium mb-1">Source:</h4>
                        <p className="text-sm text-muted-foreground">{test.source}</p>
                      </div>
                    )}
                    <div className="flex gap-2 mt-3">
                      <Button variant="outline" size="sm">
                        Edit
                      </Button>
                      <Button variant="outline" size="sm">
                        Duplicate
                      </Button>
                      <Button variant="outline" size="sm" className="text-red-500">
                        Delete
                      </Button>
                    </div>
                  </div>
                </TableCell>
              </TableRow>
            )}
          </>
        ))}
      </TableBody>
    </Table>
  )
}

