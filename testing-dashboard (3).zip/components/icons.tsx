import type { SVGProps } from "react"

export function JiraIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M11.5 16.5V21a.5.5 0 0 1-.5.5H5a.5.5 0 0 1-.5-.5V5a.5.5 0 0 1 .5-.5h6a.5.5 0 0 1 .5.5v4.5" />
      <path d="M19.5 16.5V21a.5.5 0 0 1-.5.5h-6a.5.5 0 0 1-.5-.5v-4.5" />
      <path d="M11.5 9.5V5a.5.5 0 0 1 .5-.5h6a.5.5 0 0 1 .5.5v16a.5.5 0 0 1-.5.5h-6a.5.5 0 0 1-.5-.5v-4.5" />
      <path d="M11.5 9.5h-2a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h2" />
      <path d="M11.5 16.5h2a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2h-2" />
    </svg>
  )
}

export function SlackIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M14.5 10c-.83 0-1.5-.67-1.5-1.5v-5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5v5c0 .83-.67 1.5-1.5 1.5z" />
      <path d="M20.5 10H19V8.5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5-.67 1.5-1.5 1.5z" />
      <path d="M9.5 14c.83 0 1.5.67 1.5 1.5v5c0 .83-.67 1.5-1.5 1.5S8 21.33 8 20.5v-5c0-.83.67-1.5 1.5-1.5z" />
      <path d="M3.5 14H5v1.5c0 .83-.67 1.5-1.5 1.5S2 16.33 2 15.5 2.67 14 3.5 14z" />
      <path d="M14 14.5c0-.83.67-1.5 1.5-1.5h5c.83 0 1.5.67 1.5 1.5s-.67 1.5-1.5 1.5h-5c-.83 0-1.5-.67-1.5-1.5z" />
      <path d="M15.5 19H14v1.5c0 .83.67 1.5 1.5 1.5s1.5-.67 1.5-1.5-.67-1.5-1.5-1.5z" />
      <path d="M10 9.5C10 8.67 9.33 8 8.5 8h-5C2.67 8 2 8.67 2 9.5S2.67 11 3.5 11h5c.83 0 1.5-.67 1.5-1.5z" />
      <path d="M8.5 5H10V3.5C10 2.67 9.33 2 8.5 2S7 2.67 7 3.5 7.67 5 8.5 5z" />
    </svg>
  )
}

export function CircleCiIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <circle cx="12" cy="12" r="10" />
      <circle cx="12" cy="12" r="4" />
      <path d="M12 8v-2" />
      <path d="M12 18v-2" />
      <path d="M8 12h-2" />
      <path d="M18 12h-2" />
    </svg>
  )
}

export function JenkinsIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M4.5 21h15" />
      <path d="M5.5 21V7.5a4 4 0 0 1 4-4h5a4 4 0 0 1 4 4V21" />
      <path d="M6.5 12h11" />
      <path d="M6.5 16.5h11" />
    </svg>
  )
}

export function GitlabLogoIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M22 13.29L12 21.2 2 13.29a.5.5 0 0 1-.14-.71l3.02-4.41L8 3.78a.5.5 0 0 1 .93 0l3.12 4.39H12l3.12-4.39a.5.5 0 0 1 .93 0l3.12 4.39 3.02 4.41a.5.5 0 0 1-.14.71Z" />
    </svg>
  )
}

