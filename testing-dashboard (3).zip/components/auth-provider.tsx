"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"
import { useRouter, usePathname } from "next/navigation"

type User = {
  name: string
  email: string
  avatar?: string
} | null

type AuthContextType = {
  user: User
  isAuthenticated: boolean
  login: (email: string, password: string) => Promise<void>
  register: (name: string, email: string, password: string) => Promise<void>
  logout: () => void
  loading: boolean
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  isAuthenticated: false,
  login: async () => {},
  register: async () => {},
  logout: () => {},
  loading: true,
})

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User>(null)
  const [loading, setLoading] = useState(true)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    // Check if user is authenticated on client side
    const checkAuth = () => {
      try {
        const isAuth = localStorage.getItem("isAuthenticated") === "true"
        const userData = localStorage.getItem("user")

        if (isAuth && userData) {
          setUser(JSON.parse(userData))
          setIsAuthenticated(true)
        } else {
          setUser(null)
          setIsAuthenticated(false)
        }
      } catch (error) {
        setUser(null)
        setIsAuthenticated(false)
      } finally {
        setLoading(false)
      }
    }

    checkAuth()

    // Redirect from login/register pages if already authenticated
    if ((pathname === "/login" || pathname === "/register") && localStorage.getItem("isAuthenticated") === "true") {
      router.push("/dashboard")
    }

    // Redirect to login if trying to access protected routes
    const protectedRoutes = ["/dashboard"]
    if (
      protectedRoutes.some((route) => pathname.startsWith(route)) &&
      localStorage.getItem("isAuthenticated") !== "true"
    ) {
      router.push("/login")
    }
  }, [pathname, router])

  const login = async (email: string, password: string) => {
    // In a real app, you would make an API call to authenticate
    setLoading(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Store auth state in localStorage
      localStorage.setItem("isAuthenticated", "true")
      localStorage.setItem(
        "user",
        JSON.stringify({
          name: email.split("@")[0],
          email,
          avatar: "/placeholder.svg?height=32&width=32",
        }),
      )

      setUser({ name: email.split("@")[0], email })
      setIsAuthenticated(true)
    } catch (error) {
      console.error("Login failed:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  const register = async (name: string, email: string, password: string) => {
    setLoading(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Store auth state in localStorage
      localStorage.setItem("isAuthenticated", "true")
      localStorage.setItem(
        "user",
        JSON.stringify({
          name,
          email,
          avatar: "/placeholder.svg?height=32&width=32",
        }),
      )

      setUser({ name, email })
      setIsAuthenticated(true)
    } catch (error) {
      console.error("Registration failed:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  const logout = () => {
    localStorage.removeItem("isAuthenticated")
    localStorage.removeItem("user")
    setUser(null)
    setIsAuthenticated(false)
    router.push("/login")
  }

  return (
    <AuthContext.Provider value={{ user, isAuthenticated, login, register, logout, loading }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)

