"use client"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { AlertTriangle, XCircle, ArrowUpRight } from "lucide-react"

interface MissingElement {
  id: string
  name: string
  description: string
  severity: "critical" | "high" | "medium" | "low"
  location: string
}

const mockMissingElements: MissingElement[] = [
  {
    id: "me-1",
    name: "Mobile Navigation Menu",
    description: "The navigation menu is not properly implemented for mobile devices",
    severity: "critical",
    location: "Header Component",
  },
  {
    id: "me-2",
    name: "Form Validation Messages",
    description: "Error messages are not displayed when form validation fails",
    severity: "high",
    location: "Login Form",
  },
  {
    id: "me-3",
    name: "Loading States",
    description: "Loading indicators are missing when data is being fetched",
    severity: "medium",
    location: "Dashboard Widgets",
  },
  {
    id: "me-4",
    name: "Empty State for Search Results",
    description: "No empty state is shown when search returns no results",
    severity: "high",
    location: "Search Component",
  },
  {
    id: "me-5",
    name: "Confirmation Dialog",
    description: "No confirmation dialog when deleting important items",
    severity: "critical",
    location: "Data Tables",
  },
  {
    id: "me-6",
    name: "Accessibility Labels",
    description: "Missing aria-labels on interactive elements",
    severity: "medium",
    location: "Multiple Components",
  },
  {
    id: "me-7",
    name: "Dark Mode Toggle",
    description: "No option to switch between light and dark mode",
    severity: "low",
    location: "Settings Page",
  },
]

export function MissingElements() {
  const getSeverityIcon = (severity: MissingElement["severity"]) => {
    switch (severity) {
      case "critical":
      case "high":
        return <XCircle className="h-4 w-4 text-red-500" />
      case "medium":
      case "low":
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />
    }
  }

  const getSeverityBadge = (severity: MissingElement["severity"]) => {
    switch (severity) {
      case "critical":
        return <Badge className="bg-red-500">Critical</Badge>
      case "high":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            High
          </Badge>
        )
      case "medium":
        return (
          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
            Medium
          </Badge>
        )
      case "low":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Low
          </Badge>
        )
    }
  }

  return (
    <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2">
      {mockMissingElements.map((element) => (
        <div key={element.id} className="p-3 border rounded-lg">
          <div className="flex items-start gap-2">
            {getSeverityIcon(element.severity)}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h4 className="font-medium text-sm">{element.name}</h4>
                {getSeverityBadge(element.severity)}
              </div>
              <p className="text-sm text-muted-foreground mt-1">{element.description}</p>
              <div className="flex items-center justify-between mt-2">
                <span className="text-xs text-muted-foreground">
                  Location: <span className="font-medium">{element.location}</span>
                </span>
                <Button variant="outline" size="sm" className="h-7">
                  <ArrowUpRight className="h-3.5 w-3.5 mr-1" />
                  View
                </Button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

