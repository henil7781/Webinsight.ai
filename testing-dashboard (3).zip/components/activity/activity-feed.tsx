"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { useAuth } from "@/components/auth-provider"
import { FileText, Search, Settings, Zap, BarChart2, Shield, RefreshCw, AlertTriangle } from "lucide-react"

interface Activity {
  id: string
  user: {
    name: string
    avatar?: string
    initials: string
  }
  action: string
  target: string
  timestamp: string
  type: "analyze" | "report" | "settings" | "login" | "alert" | "security" | "performance" | "seo"
  details?: string
}

const mockActivities: Activity[] = [
  {
    id: "act-1",
    user: {
      name: "You",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "Y",
    },
    action: "analyzed",
    target: "example.com",
    timestamp: "10 minutes ago",
    type: "analyze",
    details: "Completed full website analysis with 78/100 SEO score",
  },
  {
    id: "act-2",
    user: {
      name: "System",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "S",
    },
    action: "detected",
    target: "security vulnerability",
    timestamp: "25 minutes ago",
    type: "security",
    details: "Missing Content Security Policy header on mywebsite.com",
  },
  {
    id: "act-3",
    user: {
      name: "You",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "Y",
    },
    action: "generated report for",
    target: "mywebsite.com",
    timestamp: "1 hour ago",
    type: "report",
  },
  {
    id: "act-4",
    user: {
      name: "System",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "S",
    },
    action: "detected",
    target: "performance issue",
    timestamp: "2 hours ago",
    type: "performance",
    details: "Large unoptimized images affecting page load time",
  },
  {
    id: "act-5",
    user: {
      name: "You",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "Y",
    },
    action: "updated",
    target: "profile settings",
    timestamp: "3 hours ago",
    type: "settings",
  },
  {
    id: "act-6",
    user: {
      name: "System",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "S",
    },
    action: "detected",
    target: "SEO improvement opportunity",
    timestamp: "4 hours ago",
    type: "seo",
    details: "Missing meta descriptions on 5 pages",
  },
  {
    id: "act-7",
    user: {
      name: "You",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "Y",
    },
    action: "logged in from",
    target: "new device",
    timestamp: "5 hours ago",
    type: "login",
  },
  {
    id: "act-8",
    user: {
      name: "System",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "S",
    },
    action: "alert",
    target: "website down",
    timestamp: "1 day ago",
    type: "alert",
    details: "anothersite.org was unreachable for 15 minutes",
  },
]

export function ActivityFeed() {
  const { user } = useAuth()

  const getActivityIcon = (type: Activity["type"]) => {
    switch (type) {
      case "analyze":
        return <Search className="h-4 w-4 text-blue-500" />
      case "report":
        return <FileText className="h-4 w-4 text-purple-500" />
      case "settings":
        return <Settings className="h-4 w-4 text-yellow-500" />
      case "login":
        return <Zap className="h-4 w-4 text-green-500" />
      case "performance":
        return <BarChart2 className="h-4 w-4 text-orange-500" />
      case "security":
        return <Shield className="h-4 w-4 text-red-500" />
      case "seo":
        return <RefreshCw className="h-4 w-4 text-indigo-500" />
      case "alert":
        return <AlertTriangle className="h-4 w-4 text-red-500" />
    }
  }

  return (
    <div className="space-y-4 max-h-[600px] overflow-y-auto pr-1">
      {mockActivities.map((activity) => (
        <Card key={activity.id} className="p-4">
          <div className="flex items-start gap-3">
            <Avatar className="h-8 w-8">
              <AvatarImage
                src={activity.user.name === "You" ? user?.avatar : activity.user.avatar}
                alt={activity.user.name}
              />
              <AvatarFallback>
                {activity.user.name === "You" ? user?.name?.charAt(0) || "Y" : activity.user.initials}
              </AvatarFallback>
            </Avatar>
            <div className="space-y-1 flex-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">
                  {activity.user.name === "You" ? user?.name || "You" : activity.user.name}
                </span>
                {getActivityIcon(activity.type)}
                <Badge variant="outline" className="text-xs">
                  {activity.timestamp}
                </Badge>
              </div>
              <p className="text-sm">
                {activity.action} <span className="font-medium">{activity.target}</span>
              </p>
              {activity.details && (
                <p className="text-xs text-muted-foreground bg-muted p-2 rounded-md mt-2">{activity.details}</p>
              )}
              {activity.type === "security" ||
              activity.type === "performance" ||
              activity.type === "seo" ||
              activity.type === "alert" ? (
                <div className="mt-2">
                  <Button variant="outline" size="sm">
                    View Details
                  </Button>
                </div>
              ) : null}
            </div>
          </div>
        </Card>
      ))}
    </div>
  )
}

