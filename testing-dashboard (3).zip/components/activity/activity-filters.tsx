"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { FilterIcon, SearchIcon, XIcon } from "lucide-react"

export function ActivityFilters() {
  const [search, setSearch] = useState("")
  const [typeFilters, setTypeFilters] = useState({
    analyze: true,
    report: true,
    settings: true,
    login: true,
    security: true,
    performance: true,
    seo: true,
    alert: true,
  })
  const [userFilters, setUserFilters] = useState({
    you: true,
    system: true,
  })

  const clearSearch = () => {
    setSearch("")
  }

  const toggleType = (type: keyof typeof typeFilters) => {
    setTypeFilters((prev) => ({
      ...prev,
      [type]: !prev[type],
    }))
  }

  const toggleUser = (user: keyof typeof userFilters) => {
    setUserFilters((prev) => ({
      ...prev,
      [user]: !prev[user],
    }))
  }

  const resetFilters = () => {
    setTypeFilters({
      analyze: true,
      report: true,
      settings: true,
      login: true,
      security: true,
      performance: true,
      seo: true,
      alert: true,
    })
    setUserFilters({
      you: true,
      system: true,
    })
  }

  return (
    <div className="flex items-center gap-2">
      <div className="relative">
        <SearchIcon className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Search activity..."
          className="pl-8 w-full md:w-[240px]"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        {search && (
          <Button variant="ghost" size="sm" className="absolute right-0 top-0 h-9 w-9 p-0" onClick={clearSearch}>
            <XIcon className="h-4 w-4" />
            <span className="sr-only">Clear search</span>
          </Button>
        )}
      </div>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm">
            <FilterIcon className="mr-2 h-4 w-4" />
            Filter
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-[200px]">
          <DropdownMenuLabel>Activity Type</DropdownMenuLabel>
          <DropdownMenuCheckboxItem checked={typeFilters.analyze} onCheckedChange={() => toggleType("analyze")}>
            Analysis
          </DropdownMenuCheckboxItem>
          <DropdownMenuCheckboxItem checked={typeFilters.report} onCheckedChange={() => toggleType("report")}>
            Reports
          </DropdownMenuCheckboxItem>
          <DropdownMenuCheckboxItem checked={typeFilters.settings} onCheckedChange={() => toggleType("settings")}>
            Settings
          </DropdownMenuCheckboxItem>
          <DropdownMenuCheckboxItem checked={typeFilters.login} onCheckedChange={() => toggleType("login")}>
            Login
          </DropdownMenuCheckboxItem>
          <DropdownMenuCheckboxItem checked={typeFilters.security} onCheckedChange={() => toggleType("security")}>
            Security
          </DropdownMenuCheckboxItem>
          <DropdownMenuCheckboxItem checked={typeFilters.performance} onCheckedChange={() => toggleType("performance")}>
            Performance
          </DropdownMenuCheckboxItem>
          <DropdownMenuCheckboxItem checked={typeFilters.seo} onCheckedChange={() => toggleType("seo")}>
            SEO
          </DropdownMenuCheckboxItem>
          <DropdownMenuCheckboxItem checked={typeFilters.alert} onCheckedChange={() => toggleType("alert")}>
            Alerts
          </DropdownMenuCheckboxItem>

          <DropdownMenuSeparator />

          <DropdownMenuLabel>User</DropdownMenuLabel>
          <DropdownMenuCheckboxItem checked={userFilters.you} onCheckedChange={() => toggleUser("you")}>
            You
          </DropdownMenuCheckboxItem>
          <DropdownMenuCheckboxItem checked={userFilters.system} onCheckedChange={() => toggleUser("system")}>
            System
          </DropdownMenuCheckboxItem>

          <DropdownMenuSeparator />

          <Button variant="ghost" size="sm" className="w-full justify-start font-normal" onClick={resetFilters}>
            Reset Filters
          </Button>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  )
}

