"use client"

import { useState } from "react"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function ActivityCalendar() {
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [view, setView] = useState("month")

  // Mock data for activity heatmap
  const activityData = {
    "2023-05-01": 3,
    "2023-05-03": 7,
    "2023-05-05": 2,
    "2023-05-08": 5,
    "2023-05-12": 8,
    "2023-05-15": 4,
    "2023-05-18": 6,
    "2023-05-22": 9,
    "2023-05-25": 3,
    "2023-05-28": 5,
  }

  const formatDate = (date: Date): string => {
    return date.toISOString().split("T")[0]
  }

  const getActivityLevel = (date: Date): number => {
    const dateStr = formatDate(date)
    return activityData[dateStr] || 0
  }

  const getActivityColor = (level: number): string => {
    if (level === 0) return "bg-muted"
    if (level < 3) return "bg-blue-100 dark:bg-blue-900"
    if (level < 6) return "bg-blue-300 dark:bg-blue-700"
    return "bg-blue-500 dark:bg-blue-500"
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-lg font-medium">Activity Calendar</h3>
          <p className="text-sm text-muted-foreground">Visualize activity patterns over time</p>
        </div>
        <Select value={view} onValueChange={setView}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select view" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="month">Month View</SelectItem>
            <SelectItem value="week">Week View</SelectItem>
            <SelectItem value="day">Day View</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardContent className="p-4">
          <Calendar
            mode="single"
            selected={date}
            onSelect={setDate}
            className="rounded-md border"
            modifiers={{
              activity: (date) => getActivityLevel(date) > 0,
            }}
            modifiersClassNames={{
              activity: (date) => getActivityColor(getActivityLevel(date)),
            }}
          />
        </CardContent>
      </Card>

      {date && (
        <Card>
          <CardContent className="p-4">
            <h3 className="font-medium mb-2">
              Activity for{" "}
              {date.toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
            </h3>

            {getActivityLevel(date) > 0 ? (
              <div className="space-y-3">
                {Array.from({ length: getActivityLevel(date) }).map((_, i) => (
                  <div key={i} className="flex items-center justify-between p-2 border rounded-lg">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className={getActivityColor(getActivityLevel(date))}>
                        {
                          ["SEO Analysis", "Security Scan", "Performance Check", "Report Generated", "Alert Detected"][
                            i % 5
                          ]
                        }
                      </Badge>
                      <span className="text-sm">{["example.com", "mywebsite.com", "anothersite.org"][i % 3]}</span>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {`${10 + i}:${(i * 13) % 60 < 10 ? "0" : ""}${(i * 13) % 60} ${i % 2 === 0 ? "AM" : "PM"}`}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <p className="text-muted-foreground mb-4">No activity recorded for this date</p>
                <Button variant="outline" size="sm">
                  Schedule Analysis
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}

