"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useAuth } from "@/components/auth-provider"
import { FileText, Search, Settings, Zap } from "lucide-react"

interface Activity {
  id: string
  action: string
  target: string
  timestamp: string
  type: "analyze" | "report" | "settings" | "login"
}

const mockActivities: Activity[] = [
  {
    id: "act-1",
    action: "analyzed",
    target: "example.com",
    timestamp: "10 minutes ago",
    type: "analyze",
  },
  {
    id: "act-2",
    action: "generated report for",
    target: "mywebsite.com",
    timestamp: "25 minutes ago",
    type: "report",
  },
  {
    id: "act-3",
    action: "updated",
    target: "profile settings",
    timestamp: "1 hour ago",
    type: "settings",
  },
  {
    id: "act-4",
    action: "logged in from",
    target: "new device",
    timestamp: "2 hours ago",
    type: "login",
  },
  {
    id: "act-5",
    action: "analyzed",
    target: "anothersite.org",
    timestamp: "3 hours ago",
    type: "analyze",
  },
]

export function RecentActivity() {
  const { user } = useAuth()

  const getActivityIcon = (type: Activity["type"]) => {
    switch (type) {
      case "analyze":
        return <Search className="h-4 w-4 text-blue-500" />
      case "report":
        return <FileText className="h-4 w-4 text-purple-500" />
      case "settings":
        return <Settings className="h-4 w-4 text-yellow-500" />
      case "login":
        return <Zap className="h-4 w-4 text-green-500" />
    }
  }

  return (
    <div className="space-y-4">
      {mockActivities.map((activity) => (
        <div key={activity.id} className="flex items-start gap-3">
          <Avatar className="h-8 w-8">
            <AvatarImage src={user?.avatar} alt={user?.name || "User"} />
            <AvatarFallback>{user?.name?.charAt(0) || "U"}</AvatarFallback>
          </Avatar>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">You</span>
              {getActivityIcon(activity.type)}
            </div>
            <p className="text-sm text-muted-foreground">
              {activity.action} <span className="font-medium">{activity.target}</span>
            </p>
            <p className="text-xs text-muted-foreground">{activity.timestamp}</p>
          </div>
        </div>
      ))}
    </div>
  )
}

