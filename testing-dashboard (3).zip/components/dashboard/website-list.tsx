"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { ArrowUpRight, BarChart2, Search, Shield } from "lucide-react"
import Link from "next/link"

interface Website {
  id: string
  url: string
  lastAnalyzed: string
  seoScore: number
  performanceScore: number
  securityScore: number
}

const mockWebsites: Website[] = [
  {
    id: "web-1",
    url: "example.com",
    lastAnalyzed: "2 days ago",
    seoScore: 78,
    performanceScore: 85,
    securityScore: 92,
  },
  {
    id: "web-2",
    url: "mywebsite.com",
    lastAnalyzed: "1 week ago",
    seoScore: 65,
    performanceScore: 72,
    securityScore: 88,
  },
  {
    id: "web-3",
    url: "anothersite.org",
    lastAnalyzed: "3 days ago",
    seoScore: 82,
    performanceScore: 79,
    securityScore: 95,
  },
  {
    id: "web-4",
    url: "testsite.net",
    lastAnalyzed: "1 day ago",
    seoScore: 71,
    performanceScore: 68,
    securityScore: 84,
  },
]

export function WebsiteList() {
  const getScoreBadge = (score: number) => {
    if (score >= 80) {
      return <Badge className="bg-green-500">Good</Badge>
    } else if (score >= 60) {
      return (
        <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
          Needs Improvement
        </Badge>
      )
    } else {
      return (
        <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
          Poor
        </Badge>
      )
    }
  }

  return (
    <div className="space-y-4">
      {mockWebsites.map((website) => (
        <Card key={website.id}>
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h3 className="font-medium">{website.url}</h3>
                  <Badge variant="outline">Last analyzed: {website.lastAnalyzed}</Badge>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1">
                        <Search className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-medium">SEO</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm">{website.seoScore}/100</span>
                        {getScoreBadge(website.seoScore)}
                      </div>
                    </div>
                    <Progress value={website.seoScore} className="h-2" />
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1">
                        <BarChart2 className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-medium">Performance</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm">{website.performanceScore}/100</span>
                        {getScoreBadge(website.performanceScore)}
                      </div>
                    </div>
                    <Progress value={website.performanceScore} className="h-2" />
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1">
                        <Shield className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-medium">Security</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm">{website.securityScore}/100</span>
                        {getScoreBadge(website.securityScore)}
                      </div>
                    </div>
                    <Progress value={website.securityScore} className="h-2" />
                  </div>
                </div>
              </div>
              <div className="flex gap-2 md:flex-col">
                <Button variant="outline" size="sm" asChild>
                  <Link href={`/dashboard/reports/${website.id}`}>
                    View Report
                    <ArrowUpRight className="ml-1 h-3 w-3" />
                  </Link>
                </Button>
                <Button size="sm" asChild>
                  <Link href={`/dashboard/analyze?url=${website.url}`}>Analyze Again</Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

