"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { CheckCircle2, XCircle, Clock } from "lucide-react"

export function TestCaseStats() {
  const stats = {
    total: 248,
    passed: 219,
    failed: 18,
    pending: 11,
    passRate: 88.3,
    criticalPassed: 95.2,
    coverage: 76,
  }

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Total Tests</p>
              <p className="text-2xl font-bold">{stats.total}</p>
            </div>
            <div className="flex gap-2">
              <div className="flex items-center">
                <div className="h-3 w-3 rounded-full bg-green-500 mr-1.5" />
                <span className="text-xs">{stats.passed}</span>
              </div>
              <div className="flex items-center">
                <div className="h-3 w-3 rounded-full bg-red-500 mr-1.5" />
                <span className="text-xs">{stats.failed}</span>
              </div>
              <div className="flex items-center">
                <div className="h-3 w-3 rounded-full bg-yellow-500 mr-1.5" />
                <span className="text-xs">{stats.pending}</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm font-medium text-muted-foreground">Pass Rate</p>
            <div className="flex items-center">
              <CheckCircle2 className="h-4 w-4 text-green-500 mr-1" />
              <span className="text-sm font-medium">{stats.passRate}%</span>
            </div>
          </div>
          <Progress value={stats.passRate} className="h-2" />
          <div className="mt-2 flex justify-between text-xs text-muted-foreground">
            <span>Critical Features: {stats.criticalPassed}%</span>
            <span>Target: 90%</span>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-1">
            <p className="text-sm font-medium text-muted-foreground">Failed Tests</p>
            <div className="flex items-center">
              <XCircle className="h-4 w-4 text-red-500 mr-1" />
              <span className="text-sm font-medium">{stats.failed}</span>
            </div>
          </div>
          <div className="space-y-1 mt-3">
            <div className="flex justify-between text-xs">
              <span>Critical</span>
              <span className="font-medium">3</span>
            </div>
            <Progress value={(3 / stats.failed) * 100} className="h-1.5 bg-red-100" indicatorClassName="bg-red-500" />

            <div className="flex justify-between text-xs">
              <span>High</span>
              <span className="font-medium">7</span>
            </div>
            <Progress value={(7 / stats.failed) * 100} className="h-1.5 bg-red-100" indicatorClassName="bg-red-500" />

            <div className="flex justify-between text-xs">
              <span>Medium</span>
              <span className="font-medium">8</span>
            </div>
            <Progress value={(8 / stats.failed) * 100} className="h-1.5 bg-red-100" indicatorClassName="bg-red-500" />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-1">
            <p className="text-sm font-medium text-muted-foreground">Pending Tests</p>
            <div className="flex items-center">
              <Clock className="h-4 w-4 text-yellow-500 mr-1" />
              <span className="text-sm font-medium">{stats.pending}</span>
            </div>
          </div>
          <div className="space-y-1 mt-3">
            <div className="flex justify-between text-xs">
              <span>In Queue</span>
              <span className="font-medium">5</span>
            </div>
            <Progress
              value={(5 / stats.pending) * 100}
              className="h-1.5 bg-yellow-100"
              indicatorClassName="bg-yellow-500"
            />

            <div className="flex justify-between text-xs">
              <span>In Progress</span>
              <span className="font-medium">4</span>
            </div>
            <Progress
              value={(4 / stats.pending) * 100}
              className="h-1.5 bg-yellow-100"
              indicatorClassName="bg-yellow-500"
            />

            <div className="flex justify-between text-xs">
              <span>Blocked</span>
              <span className="font-medium">2</span>
            </div>
            <Progress
              value={(2 / stats.pending) * 100}
              className="h-1.5 bg-yellow-100"
              indicatorClassName="bg-yellow-500"
            />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

