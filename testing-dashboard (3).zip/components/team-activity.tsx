"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { FileText, Upload, CheckCircle2, RefreshCw, UserPlus, Settings } from "lucide-react"

interface Activity {
  id: string
  user: {
    name: string
    avatar?: string
    initials: string
  }
  action: string
  target: string
  timestamp: string
  type: "upload" | "test" | "analysis" | "fix" | "invite" | "settings"
}

const mockActivities: Activity[] = [
  {
    id: "act-1",
    user: {
      name: "Sarah Chen",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "SC",
    },
    action: "uploaded",
    target: "dashboard-design.fig",
    timestamp: "10 minutes ago",
    type: "upload",
  },
  {
    id: "act-2",
    user: {
      name: "Alex Johnson",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "AJ",
    },
    action: "ran tests on",
    target: "User Authentication Flow",
    timestamp: "25 minutes ago",
    type: "test",
  },
  {
    id: "act-3",
    user: {
      name: "Maria Garcia",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "MG",
    },
    action: "invited",
    target: "Emma Wilson",
    timestamp: "2 days ago",
    type: "invite",
  },
  {
    id: "act-4",
    user: {
      name: "John Smith",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "JS",
    },
    action: "updated",
    target: "team permissions",
    timestamp: "3 days ago",
    type: "settings",
  },
  {
    id: "act-5",
    user: {
      name: "Sarah Chen",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "SC",
    },
    action: "fixed",
    target: "Mobile Navigation Menu issue",
    timestamp: "4 days ago",
    type: "fix",
  },
]

export function TeamActivity() {
  const getActivityIcon = (type: Activity["type"]) => {
    switch (type) {
      case "upload":
        return <Upload className="h-4 w-4 text-blue-500" />
      case "test":
        return <RefreshCw className="h-4 w-4 text-purple-500" />
      case "analysis":
        return <FileText className="h-4 w-4 text-yellow-500" />
      case "fix":
        return <CheckCircle2 className="h-4 w-4 text-green-500" />
      case "invite":
        return <UserPlus className="h-4 w-4 text-blue-500" />
      case "settings":
        return <Settings className="h-4 w-4 text-gray-500" />
    }
  }

  return (
    <div className="space-y-4">
      {mockActivities.map((activity) => (
        <div key={activity.id} className="flex items-start gap-3">
          <Avatar className="h-8 w-8">
            <AvatarImage src={activity.user.avatar} alt={activity.user.name} />
            <AvatarFallback>{activity.user.initials}</AvatarFallback>
          </Avatar>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">{activity.user.name}</span>
              {getActivityIcon(activity.type)}
            </div>
            <p className="text-sm text-muted-foreground">
              {activity.action} <span className="font-medium">{activity.target}</span>
            </p>
            <p className="text-xs text-muted-foreground">{activity.timestamp}</p>
          </div>
        </div>
      ))}
    </div>
  )
}

