"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { FilterIcon, SearchIcon, XIcon } from "lucide-react"

export function TestCaseFilters() {
  const [search, setSearch] = useState("")
  const [statusFilters, setStatusFilters] = useState({
    passed: true,
    failed: true,
    pending: true,
  })
  const [priorityFilters, setPriorityFilters] = useState({
    high: true,
    medium: true,
    low: true,
  })

  const clearSearch = () => {
    setSearch("")
  }

  const toggleStatus = (status: keyof typeof statusFilters) => {
    setStatusFilters((prev) => ({
      ...prev,
      [status]: !prev[status],
    }))
  }

  const togglePriority = (priority: keyof typeof priorityFilters) => {
    setPriorityFilters((prev) => ({
      ...prev,
      [priority]: !prev[priority],
    }))
  }

  const resetFilters = () => {
    setStatusFilters({
      passed: true,
      failed: true,
      pending: true,
    })
    setPriorityFilters({
      high: true,
      medium: true,
      low: true,
    })
  }

  return (
    <div className="flex items-center gap-2">
      <div className="relative">
        <SearchIcon className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Search test cases..."
          className="pl-8 w-full md:w-[240px]"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        {search && (
          <Button variant="ghost" size="sm" className="absolute right-0 top-0 h-9 w-9 p-0" onClick={clearSearch}>
            <XIcon className="h-4 w-4" />
            <span className="sr-only">Clear search</span>
          </Button>
        )}
      </div>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm">
            <FilterIcon className="mr-2 h-4 w-4" />
            Filter
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-[200px]">
          <DropdownMenuLabel>Status</DropdownMenuLabel>
          <DropdownMenuCheckboxItem checked={statusFilters.passed} onCheckedChange={() => toggleStatus("passed")}>
            Passed
          </DropdownMenuCheckboxItem>
          <DropdownMenuCheckboxItem checked={statusFilters.failed} onCheckedChange={() => toggleStatus("failed")}>
            Failed
          </DropdownMenuCheckboxItem>
          <DropdownMenuCheckboxItem checked={statusFilters.pending} onCheckedChange={() => toggleStatus("pending")}>
            Pending
          </DropdownMenuCheckboxItem>

          <DropdownMenuSeparator />

          <DropdownMenuLabel>Priority</DropdownMenuLabel>
          <DropdownMenuCheckboxItem checked={priorityFilters.high} onCheckedChange={() => togglePriority("high")}>
            High
          </DropdownMenuCheckboxItem>
          <DropdownMenuCheckboxItem checked={priorityFilters.medium} onCheckedChange={() => togglePriority("medium")}>
            Medium
          </DropdownMenuCheckboxItem>
          <DropdownMenuCheckboxItem checked={priorityFilters.low} onCheckedChange={() => togglePriority("low")}>
            Low
          </DropdownMenuCheckboxItem>

          <DropdownMenuSeparator />

          <Button variant="ghost" size="sm" className="w-full justify-start font-normal" onClick={resetFilters}>
            Reset Filters
          </Button>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  )
}

