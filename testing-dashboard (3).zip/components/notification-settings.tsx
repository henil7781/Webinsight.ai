"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/hooks/use-toast"
import { Loader2 } from "lucide-react"

export function NotificationSettings() {
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  const [settings, setSettings] = useState({
    emailNotifications: true,
    testResults: true,
    coverageReports: true,
    teamActivity: true,
    systemUpdates: false,
    securityAlerts: true,
  })

  const handleToggle = (name: string, checked: boolean) => {
    setSettings((prev) => ({ ...prev, [name]: checked }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Notification settings updated",
        description: "Your notification preferences have been saved.",
      })
    } catch (error) {
      toast({
        title: "Failed to update settings",
        description: "There was a problem updating your notification settings.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="emailNotifications">Email Notifications</Label>
            <p className="text-sm text-muted-foreground">Receive email notifications for important updates</p>
          </div>
          <Switch
            id="emailNotifications"
            checked={settings.emailNotifications}
            onCheckedChange={(checked) => handleToggle("emailNotifications", checked)}
          />
        </div>

        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="testResults">Test Results</Label>
            <p className="text-sm text-muted-foreground">Get notified when test results are available</p>
          </div>
          <Switch
            id="testResults"
            checked={settings.testResults}
            onCheckedChange={(checked) => handleToggle("testResults", checked)}
          />
        </div>

        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="coverageReports">Coverage Reports</Label>
            <p className="text-sm text-muted-foreground">Receive weekly coverage reports</p>
          </div>
          <Switch
            id="coverageReports"
            checked={settings.coverageReports}
            onCheckedChange={(checked) => handleToggle("coverageReports", checked)}
          />
        </div>

        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="teamActivity">Team Activity</Label>
            <p className="text-sm text-muted-foreground">Get notified about team member actions</p>
          </div>
          <Switch
            id="teamActivity"
            checked={settings.teamActivity}
            onCheckedChange={(checked) => handleToggle("teamActivity", checked)}
          />
        </div>

        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="systemUpdates">System Updates</Label>
            <p className="text-sm text-muted-foreground">Receive notifications about platform updates</p>
          </div>
          <Switch
            id="systemUpdates"
            checked={settings.systemUpdates}
            onCheckedChange={(checked) => handleToggle("systemUpdates", checked)}
          />
        </div>

        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="securityAlerts">Security Alerts</Label>
            <p className="text-sm text-muted-foreground">Get notified about security-related events</p>
          </div>
          <Switch
            id="securityAlerts"
            checked={settings.securityAlerts}
            onCheckedChange={(checked) => handleToggle("securityAlerts", checked)}
          />
        </div>
      </div>

      <Button type="submit" disabled={isLoading}>
        {isLoading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Saving...
          </>
        ) : (
          "Save Preferences"
        )}
      </Button>
    </form>
  )
}

